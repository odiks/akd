package com.example.kafka.filetransfer.model;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.util.Properties;
import static org.junit.jupiter.api.Assertions.*;

class TransferConfigTest {

    @Test
    @DisplayName("La validation du Producer doit échouer si bootstrap.servers est manquant")
    void producerValidation_shouldFail_whenBootstrapServersIsMissing() {
        // Arrange
        Properties props = new Properties();
        // On ne met volontairement PAS la propriété bootstrap.servers
        props.setProperty("topic.data", "test-topic");
        props.setProperty("topic.status", "test-status");

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new TransferConfig(props, TransferConfig.AppMode.PRODUCER);
        });

        // Assert (Vérification plus fine)
        assertTrue(exception.getMessage().contains("'bootstrap.servers' est manquante"));
    }

    @Test
    @DisplayName("La validation du Producer doit réussir si toutes les propriétés requises sont là")
    void producerValidation_shouldSucceed_whenConfigIsCorrect() {
        // Arrange
        Properties props = new Properties();
        props.setProperty("bootstrap.servers", "localhost:9092");
        props.setProperty("topic.data", "test-topic");
        props.setProperty("topic.status", "test-status");

        // Act & Assert
        // assertDoesNotThrow vérifie qu'aucune exception n'est levée
        assertDoesNotThrow(() -> {
            new TransferConfig(props, TransferConfig.AppMode.PRODUCER);
        });
    }
}