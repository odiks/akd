package com.example.kafka.filetransfer.producer;

import com.example.kafka.filetransfer.kafka.KafkaChunkPublisher;
import com.example.kafka.filetransfer.model.TransferConfig;
import com.example.kafka.filetransfer.proto.FileChunkMessage;
import com.example.kafka.filetransfer.service.*;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.TopicPartition;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.nio.file.Path;
import java.util.Collections;
import java.util.Iterator;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("Tests pour FileTransferProducer")
class FileTransferProducerTest {

    @Mock private TransferConfig mockConfig;
    @Mock private KafkaChunkPublisher mockPublisher;
    // Les services sont maintenant gérés par la réflexion ou l'injection manuelle

    @Captor private ArgumentCaptor<byte[]> payloadCaptor;

    // SUPPRIMER @InjectMocks
    private FileTransferProducer fileTransferProducer;

    @BeforeEach
    void setUp() throws Exception {
        // --- INSTANCIATION MANUELLE ---
        
        // ÉTAPE 1 : Configurer les mocks AVANT d'appeler le constructeur
        when(mockConfig.getChunkSize()).thenReturn(1024); // Fournit une valeur valide

        // ÉTAPE 2 : Créer l'instance à tester
        fileTransferProducer = new FileTransferProducer(mockConfig);

        // ÉTAPE 3 : Remplacer le publisher interne par notre mock
        // C'est nécessaire car le constructeur crée sa propre instance de KafkaChunkPublisher
        java.lang.reflect.Field publisherField = FileTransferProducer.class.getDeclaredField("publisher");
        publisherField.setAccessible(true);
        publisherField.set(fileTransferProducer, mockPublisher);
    }

    @Test
    @DisplayName("Doit envoyer les chunks et un message final")
    void startTransfer_shouldSendChunksAndFinalMessage() throws Exception {
        // Arrange
        Path dummyPath = Path.of("dummy.txt");
        byte[] dummyChunk = "data".getBytes();
        Iterator<byte[]> dummyIterator = Collections.singletonList(dummyChunk).iterator();

        // On utilise la réflexion pour remplacer les services internes par des mocks
        // C'est une solution pour tester le code tel quel. L'idéal serait l'injection de dépendances.
        ManifestService mockManifestService = mock(ManifestService.class);
        when(mockManifestService.createManifest(any(), anyString())).thenReturn(FileChunkMessage.newBuilder());
        setField(fileTransferProducer, "manifestService", mockManifestService);

        ChunkingService mockChunkingService = mock(ChunkingService.class);
        when(mockChunkingService.iterateChunks(any())).thenReturn(dummyIterator);
        setField(fileTransferProducer, "chunkingService", mockChunkingService);

        HashingService mockHashingService = mock(HashingService.class);
        when(mockHashingService.calculateFileHash(any(), anyString())).thenReturn("file-hash");
        setField(fileTransferProducer, "hashingService", mockHashingService);

        CryptoService mockCryptoService = mock(CryptoService.class);
        when(mockCryptoService.prepareEncryption()).thenReturn(CryptoService.EncryptionResult.unencrypted());
        setField(fileTransferProducer, "cryptoService", mockCryptoService);

        // Simule un envoi synchrone réussi
        RecordMetadata dummyMetadata = new RecordMetadata(new TopicPartition("test", 0), 0, 0, 0, 0, 0);
        when(mockPublisher.publishSync(anyString(), any())).thenReturn(CompletableFuture.completedFuture(dummyMetadata));
        
        // Act
        fileTransferProducer.startTransfer(dummyPath);

        // Assert
        verify(mockPublisher, times(1)).publishSync(anyString(), any()); // Le premier chunk
        verify(mockPublisher, times(1)).publishSync(anyString(), payloadCaptor.capture()); // Le message final

        byte[] finalPayload = payloadCaptor.getValue();
        FileChunkMessage finalMessage = FileChunkMessage.parseFrom(finalPayload);
        assertTrue(finalMessage.getIsFinalChunk());
    }

    // Helper pour injecter les mocks par réflexion
    private void setField(Object target, String fieldName, Object value) throws Exception {
        java.lang.reflect.Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }
}