package com.example.kafka.filetransfer.consumer;

import com.example.kafka.filetransfer.model.InProgressTransfer;
import com.example.kafka.filetransfer.model.TransferConfig;
import com.example.kafka.filetransfer.proto.FileChunkMessage;
import com.example.kafka.filetransfer.proto.HashAlgorithm;
import com.example.kafka.filetransfer.service.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Properties;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("Tests pour FileTransferConsumer")
class FileTransferConsumerTest {

    @Mock private TransferConfig mockConfig;
    @Mock private ManifestService mockManifestService;
    @Mock private HashingService mockHashingService;
    @Mock private CompressionService mockCompressionService;
    @Mock private CryptoService mockCryptoService;

    // SUPPRIMER @InjectMocks
    private FileTransferConsumer fileTransferConsumer;

    @TempDir Path tempDir;

    @BeforeEach
    void setUp() {
        // --- INSTANCIATION MANUELLE ---

        // ÉTAPE 1 : Configurer le mock AVANT l'appel au constructeur
        when(mockConfig.getKafkaConsumerProperties()).thenReturn(new Properties()); // Retourne un objet valide
        when(mockConfig.getStagingDirectory()).thenReturn(tempDir.toString());

        // ÉTAPE 2 : Créer l'instance à tester
        // Le constructeur du consumer prend aussi un Path, on le fournit.
        fileTransferConsumer = new FileTransferConsumer(mockConfig, tempDir);
        
        // ÉTAPE 3 : Remplacer les services internes par nos mocks
        // Comme pour le producer, on utilise la réflexion car le constructeur crée ses propres instances.
        try {
            setField(fileTransferConsumer, "manifestService", mockManifestService);
            setField(fileTransferConsumer, "hashingService", mockHashingService);
            setField(fileTransferConsumer, "compressionService", mockCompressionService);
            setField(fileTransferConsumer, "cryptoService", mockCryptoService);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    @DisplayName("La reconstruction doit assembler les chunks, vérifier le hash et nettoyer")
    void reconstructFile_shouldAssembleChunks_VerifyHash_andCleanup() throws Exception {
        // Arrange
        Path stagingDir = tempDir.resolve("staging-123");
        Files.createDirectories(stagingDir);
        Files.write(stagingDir.resolve("1.chunk"), "Hello ".getBytes());
        Files.write(stagingDir.resolve("2.chunk"), "World!".getBytes());
        
        InProgressTransfer mockTransfer = mock(InProgressTransfer.class);
        when(mockTransfer.getSortedChunkFiles()).thenReturn(List.of(
            stagingDir.resolve("1.chunk"),
            stagingDir.resolve("2.chunk")
        ));
        when(mockTransfer.getStagingDirectory()).thenReturn(stagingDir);

        FileChunkMessage metadata = FileChunkMessage.newBuilder()
            .setFileName("result.txt")
            .setFileHash("expected-hash")
            .setHashAlgorithm(HashAlgorithm.SHA_256)
            .build();
        when(mockTransfer.getFinalChunkMetadata()).thenReturn(metadata);

        when(mockCompressionService.decompress(any(), anyString())).thenAnswer(inv -> inv.getArgument(0));
        when(mockCryptoService.decrypt(any(), any(), anyString())).thenAnswer(inv -> inv.getArgument(0));
        
        // Act
        java.lang.reflect.Method reconstructMethod = FileTransferConsumer.class
            .getDeclaredMethod("reconstructFile", InProgressTransfer.class, String.class);
        reconstructMethod.setAccessible(true);
        reconstructMethod.invoke(fileTransferConsumer, mockTransfer, "[TID:123] ");
        
        // Assert
        Path finalPath = tempDir.resolve("result.txt");
        assertTrue(Files.exists(finalPath));
        assertEquals("Hello World!", Files.readString(finalPath));
        verify(mockHashingService).verifyFileIntegrity(any(), eq("expected-hash"), any());
        verify(mockManifestService).applyMetadata(any(), any());
        assertFalse(Files.exists(stagingDir));
    }
    
    private void setField(Object target, String fieldName, Object value) throws Exception {
        java.lang.reflect.Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }
}