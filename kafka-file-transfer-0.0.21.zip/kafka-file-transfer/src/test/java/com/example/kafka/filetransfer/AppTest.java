package com.example.kafka.filetransfer;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import picocli.CommandLine;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Tests pour le point d'entrée de l'application (App.java)")
class AppTest {

    // On va capturer la sortie de la console pour vérifier les messages d'aide
    private final PrintStream originalOut = System.out;
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();

    @BeforeEach
    public void setUpStreams() {
        System.setOut(new PrintStream(outContent));
    }

    @AfterEach
    public void restoreStreams() {
        System.setOut(originalOut);
    }

    @Test
    @DisplayName("L'option --help doit afficher le message d'aide et quitter avec le code 0")
    void testHelpOptionPrintsUsageAndExitsCorrectly() {
        // Arrange
        String[] args = {"--help"};

        // Act
        int exitCode = new CommandLine(new App()).execute(args);

        // Assert
        assertEquals(0, exitCode, "Le code de sortie pour --help doit être 0");
        String output = outContent.toString();
        assertTrue(output.contains("Usage: file-transfer-app"), "La sortie doit contenir le message d'usage");
        assertTrue(output.contains("producer"), "La sortie doit mentionner la sous-commande 'producer'");
        assertTrue(output.contains("consumer"), "La sortie doit mentionner la sous-commande 'consumer'");
    }

    @Test
    @DisplayName("L'argument 'producer' doit être reconnu avec ses arguments requis")
    void testProducerSubcommandIsRecognized() {
        // Arrange
        CommandLine cmd = new CommandLine(new App());
        // AJOUT: On fournit des arguments factices pour satisfaire la validation de Picocli
        String[] args = {"producer", "dummy-file.txt", "--config", "dummy-config.properties"};

        // Act: On ne fait que parser les arguments, pas les exécuter.
        CommandLine.ParseResult parseResult = cmd.parseArgs(args);

        // Assert
        assertTrue(parseResult.hasSubcommand(), "La sous-commande 'producer' aurait dû être trouvée");
        assertEquals("producer", parseResult.subcommand().commandSpec().name());
    }

    @Test
    @DisplayName("L'argument 'consumer' doit être reconnu avec ses arguments requis")
    void testConsumerSubcommandIsRecognized() {
        // Arrange
        CommandLine cmd = new CommandLine(new App());
        // AJOUT: On fournit des arguments factices pour satisfaire la validation de Picocli
        String[] args = {"consumer", "--destination-dir", "dummy-dir", "--config", "dummy-config.properties"};

        // Act
        CommandLine.ParseResult parseResult = cmd.parseArgs(args);

        // Assert
        assertTrue(parseResult.hasSubcommand(), "La sous-commande 'consumer' aurait dû être trouvée");
        assertEquals("consumer", parseResult.subcommand().commandSpec().name());
    }
}