package com.example.kafka.filetransfer;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DisplayName("Tests pour l'énumération ErrorCode")
class ErrorCodeTest {

    @Test
    @DisplayName("Les getters doivent retourner les bonnes valeurs pour les codes")
    void testGettersReturnCorrectValues() {
        // Arrange & Act & Assert
        assertEquals(0, ErrorCode.OK.getCode());
        assertEquals("Opération réussie", ErrorCode.OK.getDescription());

        assertEquals(30, ErrorCode.KAFKA_ERROR.getCode());
        assertEquals("Erreur de communication avec le cluster Kafka", ErrorCode.KAFKA_ERROR.getDescription());

        assertEquals(99, ErrorCode.UNKNOWN.getCode());
        assertEquals("Erreur inconnue ou non gérée", ErrorCode.UNKNOWN.getDescription());
    }

    @Test
    @DisplayName("Tous les codes d'erreur numériques doivent être uniques")
    void testErrorCodesAreUnique() {
        // Arrange
        Set<Integer> codes = new HashSet<>();

        // Act & Assert
        for (ErrorCode errorCode : ErrorCode.values()) {
            boolean isNew = codes.add(errorCode.getCode());
            assertTrue(isNew, "Le code d'erreur " + errorCode.getCode() + " est dupliqué ! (" + errorCode.name() + ")");
        }
    }
}