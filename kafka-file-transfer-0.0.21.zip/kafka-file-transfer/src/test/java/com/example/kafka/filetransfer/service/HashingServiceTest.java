package com.example.kafka.filetransfer.service;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.nio.charset.StandardCharsets;
import static org.junit.jupiter.api.Assertions.*;

class HashingServiceTest {

    private final HashingService hashingService = new HashingService();

    @Test
    @DisplayName("Le calcul du hash SHA-256 d'un chunk doit être correct")
    void testCalculateChunkHash_SHA256() throws Exception {
        // Arrange (Préparation)
        String inputData = "hello world";
        String expectedHash = "b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9";
        byte[] inputBytes = inputData.getBytes(StandardCharsets.UTF_8);

        // Act (Action)
        String actualHash = hashingService.calculateChunkHash(inputBytes, "SHA-256");

        // Assert (Vérification)
        assertEquals(expectedHash, actualHash);
    }

    @Test
    @DisplayName("Le calcul du hash d'un chunk avec un algo inconnu doit lever une exception")
    void testCalculateChunkHash_UnknownAlgo() {
        // Arrange
        byte[] inputBytes = "test".getBytes();

        // Act & Assert
        assertThrows(java.security.NoSuchAlgorithmException.class, () -> {
            hashingService.calculateChunkHash(inputBytes, "SHA-IMAGINAIRE");
        });
    }
}