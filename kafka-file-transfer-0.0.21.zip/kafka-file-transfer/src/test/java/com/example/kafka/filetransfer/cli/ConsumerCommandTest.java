package com.example.kafka.filetransfer.cli;

import com.example.kafka.filetransfer.ErrorCode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import picocli.CommandLine;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DisplayName("Tests pour ConsumerCommand")
class ConsumerCommandTest {

    // JUnit 5 gère la création et le nettoyage de ce répertoire temporaire
    @TempDir
    Path tempDir;

    private File validConfigFile;
    private File validDestinationDir;

    @BeforeEach
    void setUp() throws IOException {
        // Crée un fichier de configuration factice mais valide
        validConfigFile = Files.createFile(tempDir.resolve("consumer.properties")).toFile();
        try (PrintWriter writer = new PrintWriter(validConfigFile)) {
            writer.println("bootstrap.servers=localhost:9092");
            writer.println("topic.data=test");
            writer.println("topic.status=test-status");
            writer.println("group.id=test-group");
            writer.println("staging.directory=" + tempDir.toString());
            writer.println("encryption.private_key.path=dummy.key"); // Requis par la validation
        }

        // Crée un répertoire de destination factice mais valide
        validDestinationDir = Files.createDirectory(tempDir.resolve("dest")).toFile();
    }

    @Test
    @DisplayName("Doit retourner VALIDATION_ERROR si le répertoire de destination n'existe pas")
    void call_shouldReturnValidationError_whenDestinationDirDoesNotExist() {
        // Arrange
        ConsumerCommand consumerCommand = new ConsumerCommand();
        CommandLine cmd = new CommandLine(consumerCommand);
        String nonExistentDir = tempDir.resolve("non-existent-dir").toString();

        // Act
        int exitCode = cmd.execute("-d", nonExistentDir, "-c", validConfigFile.getAbsolutePath());

        // Assert
        assertEquals(ErrorCode.VALIDATION_ERROR.getCode(), exitCode);
    }

    @Test
    @DisplayName("Doit retourner IO_ERROR si on ne peut pas écrire dans le répertoire de destination")
    void call_shouldReturnIoError_whenDestinationDirIsNotWritable() {
        // Arrange
        ConsumerCommand consumerCommand = new ConsumerCommand();
        CommandLine cmd = new CommandLine(consumerCommand);
        
        // Rend le répertoire non-accessible en écriture
        boolean madeUnwritable = validDestinationDir.setWritable(false);
        // Si le système d'exploitation ne permet pas de changer les permissions, on saute le test
        if (!madeUnwritable) {
            System.out.println("WARN: Impossible de rendre le répertoire non-accessible en écriture, test sauté.");
            return;
        }

        // Act
        int exitCode = cmd.execute("-d", validDestinationDir.getAbsolutePath(), "-c", validConfigFile.getAbsolutePath());

        // Assert
        assertEquals(ErrorCode.IO_ERROR.getCode(), exitCode);

        // Nettoyage : Rendre le répertoire à nouveau accessible en écriture pour que JUnit puisse le supprimer
        validDestinationDir.setWritable(true);
    }

    @Test
    @DisplayName("Doit retourner CONFIG_ERROR si le fichier de configuration n'existe pas")
    void call_shouldReturnConfigError_whenConfigFileDoesNotExist() {
        // Arrange
        ConsumerCommand consumerCommand = new ConsumerCommand();
        CommandLine cmd = new CommandLine(consumerCommand);
        String nonExistentConfig = tempDir.resolve("non-existent.properties").toString();

        // Act
        int exitCode = cmd.execute("-d", validDestinationDir.getAbsolutePath(), "-c", nonExistentConfig);

        // Assert
        assertEquals(ErrorCode.CONFIG_ERROR.getCode(), exitCode);
    }

    // Comme pour ProducerCommand, tester le cas de succès est plus complexe car cela
    // implique de lancer la boucle infinie du consommateur. On se concentre donc sur la
    // validation des entrées, qui est le rôle principal de la classe Command.
}