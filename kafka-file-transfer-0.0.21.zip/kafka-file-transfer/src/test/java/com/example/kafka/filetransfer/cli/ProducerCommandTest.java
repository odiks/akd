package com.example.kafka.filetransfer.cli;

import com.example.kafka.filetransfer.ErrorCode;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import picocli.CommandLine;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DisplayName("Tests pour ProducerCommand")
class ProducerCommandTest {

    // JUnit 5 va créer et nettoyer ce répertoire temporaire pour nous
    @TempDir
    Path tempDir;

    private File validConfigFile;
    private File validSourceFile;

    @BeforeEach
    void setUp() throws IOException {
        // Crée des fichiers factices valides pour les tests
        validConfigFile = Files.createFile(tempDir.resolve("producer.properties")).toFile();
        try (PrintWriter writer = new PrintWriter(validConfigFile)) {
            writer.println("bootstrap.servers=localhost:9092");
            writer.println("topic.data=test");
            writer.println("topic.status=test-status");
        }

        validSourceFile = Files.createFile(tempDir.resolve("source.txt")).toFile();
    }

    @Test
    @DisplayName("Doit retourner VALIDATION_ERROR si le fichier source n'existe pas")
    void call_shouldReturnValidationError_whenSourceFileDoesNotExist() {
        // Arrange
        ProducerCommand producerCommand = new ProducerCommand();
        CommandLine cmd = new CommandLine(producerCommand);

        // Act
        int exitCode = cmd.execute("non-existent-file.txt", "-c", validConfigFile.getAbsolutePath());

        // Assert
        assertEquals(ErrorCode.VALIDATION_ERROR.getCode(), exitCode);
    }

    @Test
    @DisplayName("Doit retourner CONFIG_ERROR si le fichier de config n'existe pas")
    void call_shouldReturnConfigError_whenConfigFileDoesNotExist() {
        // Arrange
        ProducerCommand producerCommand = new ProducerCommand();
        CommandLine cmd = new CommandLine(producerCommand);

        // Act
        int exitCode = cmd.execute(validSourceFile.getAbsolutePath(), "-c", "non-existent-config.properties");

        // Assert
        assertEquals(ErrorCode.CONFIG_ERROR.getCode(), exitCode);
    }
    
    // Note: un test de succès complet nécessiterait de mocker FileTransferProducer,
    // ce qui est possible mais plus complexe. Ces tests de validation sont les plus importants.
}