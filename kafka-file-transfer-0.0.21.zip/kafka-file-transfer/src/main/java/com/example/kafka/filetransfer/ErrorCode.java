package com.example.kafka.filetransfer;

/**
 * Énumération centralisée des codes de sortie pour l'application.
 * Chaque code a une signification précise, permettant un scripting et un monitoring robustes.
 */
public enum ErrorCode {

    /** Opération terminée avec succès. */
    OK(0, "Opération réussie"),

    /** Une erreur s'est produite lors de la lecture ou de la validation du fichier de configuration. */
    CONFIG_ERROR(10, "Erreur de configuration ou fichier de propriétés invalide"),

    /** Un argument passé en ligne de commande est invalide (ex: fichier non trouvé, répertoire invalide). */
    VALIDATION_ERROR(11, "Argument d'entrée invalide"),
    
    /** Une erreur d'entrée/sortie s'est produite (ex: lecture du fichier source, écriture du fichier de destination). */
    IO_ERROR(20, "Erreur d'entrée/sortie, fichier inaccessible ou disque plein"),

    /** Une erreur de communication avec le cluster Kafka (ex: broker injoignable, timeout). */
    KAFKA_ERROR(30, "Erreur de communication avec le cluster Kafka"),

    /** Une erreur s'est produite durant une opération cryptographique (chiffrement, déchiffrement, signature). */
    CRYPTO_ERROR(40, "Erreur de chiffrement ou de signature"),

    /** Le hash du fichier reconstruit ne correspond pas au hash du fichier original. */
    INTEGRITY_FAILED(50, "La vérification d'intégrité (hash) a échoué"),

    /** Une erreur inattendue et non catégorisée s'est produite. */
    UNKNOWN(99, "Erreur inconnue ou non gérée");

    private final int code;
    private final String description;

    /**
     * Constructeur de l'énumération.
     * @param code Le code numérique à retourner au système d'exploitation.
     * @param description Une description lisible de l'erreur.
     */
    ErrorCode(int code, String description) {
        this.code = code;
        this.description = description;
    }

    /**
     * Retourne le code numérique de l'erreur.
     * @return le code de sortie.
     */
    public int getCode() {
        return code;
    }

    /**
     * Retourne la description lisible de l'erreur.
     * @return la description.
     */
    public String getDescription() {
        return description;
    }
}