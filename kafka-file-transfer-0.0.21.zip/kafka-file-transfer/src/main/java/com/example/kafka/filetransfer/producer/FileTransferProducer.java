package com.example.kafka.filetransfer.producer;

import com.example.kafka.filetransfer.kafka.KafkaChunkPublisher;
import com.example.kafka.filetransfer.model.TransferConfig;
import com.example.kafka.filetransfer.proto.FileChunkMessage;
import com.example.kafka.filetransfer.proto.CompressionAlgorithm;
import org.apache.kafka.clients.producer.RecordMetadata;
import com.example.kafka.filetransfer.service.*;
import com.google.protobuf.ByteString;
import com.google.protobuf.StringValue;
import com.google.protobuf.util.JsonFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.kafka.common.KafkaException; // <-- IMPORT AJOUTÉ
import java.util.concurrent.atomic.AtomicBoolean; // <-- IMPORT AJOUTÉ

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.UUID;

public class FileTransferProducer {

    private static final Logger logger = LoggerFactory.getLogger(FileTransferProducer.class);

    private final TransferConfig config;
    private final ManifestService manifestService;
    private final HashingService hashingService;
    private final CompressionService compressionService;
    private final CryptoService cryptoService;
    private final ChunkingService chunkingService;

    public FileTransferProducer(TransferConfig config) {
        this.config = config;
        this.manifestService = new ManifestService();
        this.hashingService = new HashingService();
        this.compressionService = new CompressionService();
        this.cryptoService = new CryptoService(config);
        this.chunkingService = new ChunkingService(config.getChunkSize());
    }

    public void startTransfer(Path filePath) throws Exception {
        String transferId = UUID.randomUUID().toString();
        String tidLogPrefix = "[TID:" + transferId.substring(0, 8) + "] ";

        // NOUVEAU: Variables pour stocker les métadonnées de début et de fin
        RecordMetadata firstChunkMetadata = null;
        RecordMetadata finalChunkMetadata;

        // NOUVEAU: Création du drapeau de communication pour ce transfert spécifique
        final AtomicBoolean transferFailed = new AtomicBoolean(false);

        try (KafkaChunkPublisher publisher = new KafkaChunkPublisher(config)) {
            logger.info("{}Événement de transfert : [STATUS={}] - Démarrage du transfert pour le fichier '{}'", tidLogPrefix, "TRANSFER_STARTED", filePath.getFileName());

            // --- ÉTAPE 1: Création du manifeste et calcul du hash original (en streaming) ---
            FileChunkMessage.Builder manifest = manifestService.createManifest(filePath, transferId);
            String fullFileHash = hashingService.calculateFileHash(filePath, config.getHashAlgorithm());
            manifest.setFileHash(fullFileHash);
            // Remplacer FileChunkMessage.CompressionAlgorithm par juste CompressionAlgorithm
            manifest.setCompressionAlgorithm(CompressionAlgorithm.valueOf(config.getCompressionAlgorithm().toUpperCase()));
            logger.info("{}Hash du fichier original calculé : {}", tidLogPrefix, fullFileHash);

            // --- ÉTAPE 2: Préparation du chiffrement (si activé) ---
            CryptoService.EncryptionResult encryptionResult = cryptoService.prepareEncryption();
            
            // Le nombre total de chunks est calculé sur le fichier original, ce qui est plus prévisible.
            final int totalChunks = (int) Math.ceil((double) Files.size(filePath) / config.getChunkSize());
            manifest.setTotalChunks(totalChunks);
            logger.info("{}Le fichier sera découpé en {} chunks.", tidLogPrefix, totalChunks);

            // --- ÉTAPE 3: Boucle de traitement en streaming ---
            // L'itérateur lit le fichier chunk par chunk, sans jamais le charger en entier.
            Iterator<byte[]> chunkIterator = chunkingService.iterateChunks(filePath);
           
            int chunkNumber = 0;
            while (chunkIterator.hasNext()) {
                // MODIFICATION: Arrêter la boucle si le drapeau a été levé par un envoi précédent
                if (transferFailed.get()) {
                    throw new KafkaException("Échec de l'envoi d'un chunk précédent. Annulation du transfert " + transferId);
                }

                chunkNumber++;
                byte[] originalChunkData = chunkIterator.next();
                String chunkHash = hashingService.calculateChunkHash(originalChunkData, config.getHashAlgorithm());

                // Applique la compression puis le chiffrement sur chaque chunk individuellement.
                byte[] compressedData = compressionService.compress(originalChunkData, config.getCompressionAlgorithm());
                byte[] processedData = cryptoService.encrypt(compressedData, encryptionResult);

                FileChunkMessage.Builder chunkMessageBuilder = manifest.clone()
                        .setChunkNumber(chunkNumber)
                        .setChunkHash(chunkHash)
                        .setOriginalChunkSize(originalChunkData.length) // Taille avant compression/chiffrement
                        .setData(ByteString.copyFrom(processedData));
                
                byte[] payload = serialize(chunkMessageBuilder.build());

                // MODIFICATION: Logique d'envoi différenciée
                if (chunkNumber == 1) {
                    // Envoyer le PREMIER chunk de manière SYNCHRONE pour obtenir l'offset de départ
                    firstChunkMetadata = publisher.publishSync(transferId, payload).get();
                } else {
                    // Envoyer les autres chunks de manière ASYNCHRONE pour la performance
                  
                    publisher.publish(transferId, payload, chunkNumber + "/" + totalChunks, transferFailed);
                }
                logger.debug("{}Chunk {} publié.", tidLogPrefix, chunkNumber + "/" + totalChunks);
            }

            // NOUVEAU: Une dernière vérification avant d'envoyer le message final
            if (transferFailed.get()) {
                throw new KafkaException("Échec de l'envoi du dernier chunk. Annulation du transfert " + transferId);
            }

            // --- ÉTAPE 4: Envoi du message final avec les métadonnées de chiffrement ---
            logger.info("{}Tous les chunks de données ont été publiés. Envoi du message final.", tidLogPrefix);
            FileChunkMessage finalMessageProto = buildFinalMessage(manifest, encryptionResult);
            byte[] finalPayload = serialize(finalMessageProto);
            finalChunkMetadata = publisher.publishSync(transferId, finalPayload).get(); // Déjà synchrone


            /// NOUVEAU: Construire une information contextuelle sur la compression
            String compressionInfo = "";
            if (!config.getCompressionAlgorithm().equalsIgnoreCase("NONE")) {
                compressionInfo = String.format(" (Compression: %s)", config.getCompressionAlgorithm());
            }

            if (firstChunkMetadata != null) {
                logger.info("{}Événement de transfert : [STATUS={}] - Transfert de '{}' complété{}. {} chunks écrits sur la partition {}-{} dans la plage d'offsets [{}...{}].",
                        tidLogPrefix,
                        "TRANSFER_COMPLETED_PRODUCER",
                        filePath.getFileName(),
                        compressionInfo, // <-- AJOUT DE L'INFO ICI
                        totalChunks,
                        finalChunkMetadata.topic(),
                        firstChunkMetadata.partition(),
                        firstChunkMetadata.offset(),
                        finalChunkMetadata.offset()
                );
            } else if (totalChunks == 0) {
                 logger.info("{}Événement de transfert : [STATUS={}] - Transfert de '{}' complété. Le fichier est vide.", tidLogPrefix, "TRANSFER_COMPLETED_PRODUCER", filePath.getFileName());
            }

        }
    }

    private byte[] serialize(FileChunkMessage message) throws Exception {
        if (config.getSerializationFormat() == TransferConfig.SerializationFormat.JSON) {
            // Utilisation directe de l'utilitaire de Protobuf, beaucoup plus simple et efficace.
            return JsonFormat.printer().print(message).getBytes(StandardCharsets.UTF_8);
        } else {
            return message.toByteArray();
        }
    }

    private FileChunkMessage buildFinalMessage(FileChunkMessage.Builder manifest, CryptoService.EncryptionResult encryptionResult) {
        // Le message final ne contient pas de données, mais contient les infos de chiffrement.
        if (encryptionResult.isEncrypted()) {
            manifest.setEncryptedSymmetricKey(ByteString.copyFrom(encryptionResult.getEncryptedSymmetricKey()));
            manifest.setEncryptionCipher(StringValue.of(encryptionResult.getCipherName()));
        }
        // Marque ce message comme étant le dernier, signalant la fin du transfert.
        return manifest.setIsFinalChunk(true)
                .clearData() // On s'assure qu'il n'y a pas de data dans le message final
                .build();
    }
}