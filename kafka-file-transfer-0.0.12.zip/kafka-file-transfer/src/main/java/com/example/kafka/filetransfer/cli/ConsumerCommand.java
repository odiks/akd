package com.example.kafka.filetransfer.cli;

import com.example.kafka.filetransfer.ErrorCode;
import com.example.kafka.filetransfer.consumer.FileTransferConsumer;
import com.example.kafka.filetransfer.model.TransferConfig;
import org.apache.kafka.common.errors.InterruptException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Optional;
import java.util.Properties;
import java.util.concurrent.Callable;

@Command(name = "consumer",
         mixinStandardHelpOptions = true,
         description = "Écoute un topic Kafka, assemble les chunks et reconstruit les fichiers. Peut aussi s'exécuter en mode de récupération.")
public class ConsumerCommand implements Callable<Integer> {

    private static final Logger logger = LoggerFactory.getLogger(ConsumerCommand.class);

    @Option(names = {"-d", "--destination-dir"}, required = true, description = "Répertoire de destination.")
    private File destinationDir;

    @Option(names = {"-c", "--config"}, required = true, description = "Chemin vers le fichier de propriétés.")
    private File configFile;

    @Override
    public Integer call() {
        try {
            MDC.put("hostname", InetAddress.getLocalHost().getHostName());
        } catch (UnknownHostException e) {
            MDC.put("hostname", "unknown");
        }
        MDC.put("appName", "consumer-cli");

        try {
            // 1. Validation initiale des arguments
            if (!destinationDir.exists() || !destinationDir.isDirectory()) {
                logger.error("Erreur de validation : Le répertoire de destination '{}' n'existe pas ou n'est pas un répertoire.", destinationDir.getAbsolutePath());
                return ErrorCode.VALIDATION_ERROR.getCode();
            }
            if (!destinationDir.canWrite()) {
                logger.error("Erreur d'IO : Impossible d'écrire dans le répertoire de destination '{}'.", destinationDir.getAbsolutePath());
                return ErrorCode.IO_ERROR.getCode();
            }

            // 2. Chargement de la configuration
            Properties props = new Properties();
            try (FileInputStream fis = new FileInputStream(configFile)) {
                props.load(fis);
            } catch (FileNotFoundException e) {
                logger.error("Erreur de configuration : Le fichier de propriétés '{}' est introuvable.", configFile.getAbsolutePath());
                return ErrorCode.CONFIG_ERROR.getCode();
            } catch (IOException e) {
                logger.error("Erreur d'IO : Impossible de lire le fichier de propriétés '{}'.", configFile.getAbsolutePath(), e);
                return ErrorCode.IO_ERROR.getCode();
            }

            // 3. Lancement du processus
            TransferConfig transferConfig = new TransferConfig(props);
            FileTransferConsumer consumer = new FileTransferConsumer(transferConfig, destinationDir.toPath());

            // =============================================================
            // NOUVELLE LOGIQUE : CHOIX DU MODE D'EXÉCUTION
            // =============================================================
            Optional<String> recoveryId = transferConfig.getRecoveryTransferId();
            if (recoveryId.isPresent()) {
                // Mode de récupération : exécution ponctuelle
                logger.warn("!!! DÉMARRAGE EN MODE RÉCUPÉRATION D'URGENCE POUR L'ID : {} !!!", recoveryId.get());
                boolean success = consumer.startRecovery(recoveryId.get());
                if (success) {
                    logger.info("Récupération terminée avec succès. [exitCode={}]", ErrorCode.OK.getCode());
                    return ErrorCode.OK.getCode();
                } else {
                    logger.error("La récupération a échoué. Le transfert n'a pas pu être trouvé ou complété. [exitCode={}]", ErrorCode.UNKNOWN.getCode());
                    return ErrorCode.UNKNOWN.getCode();
                }
            } else {
                // Mode normal : écoute continue
                Runtime.getRuntime().addShutdownHook(new Thread(consumer::shutdown));
                consumer.start();
                logger.info("Processus consommateur terminé normalement. [exitCode={}]", ErrorCode.OK.getCode());
                return ErrorCode.OK.getCode();
            }

        } catch (IllegalArgumentException e) {
            logger.error("Erreur de configuration : {}.", e.getMessage());
            return ErrorCode.CONFIG_ERROR.getCode();
        } catch (InterruptException e) {
            logger.warn("Processus consommateur interrompu par l'utilisateur (Ctrl+C). Fermeture propre.");
            return ErrorCode.OK.getCode();
        } catch (Exception e) {
            logger.error("Erreur Inconnue critique dans le consommateur : {}.", e.getMessage(), e);
            return ErrorCode.UNKNOWN.getCode();
        } finally {
            MDC.clear();
        }
    }
}