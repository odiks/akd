package com.example.kafka.filetransfer.service;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Service responsable du découpage d'un fichier en chunks.
 * Fournit un itérateur pour lire le fichier chunk par chunk sans le charger entièrement en mémoire.
 */
public class ChunkingService {

    private final int chunkSize;

    public ChunkingService(int chunkSize) {
        if (chunkSize <= 0) {
            throw new IllegalArgumentException("La taille des chunks doit être positive.");
        }
        this.chunkSize = chunkSize;
    }

    /**
     * Retourne un itérateur qui lit le fichier et produit des chunks de la taille configurée.
     * @param filePath Le chemin vers le fichier à lire.
     * @return Un itérateur sur les chunks (byte[]).
     * @throws IOException si le fichier ne peut pas être ouvert.
     */
    public Iterator<byte[]> iterateChunks(Path filePath) throws IOException {
        InputStream inputStream = Files.newInputStream(filePath);
        
        return new Iterator<>() {
            private byte[] nextChunk = null;
            private boolean done = false;

            @Override
            public boolean hasNext() {
                if (nextChunk != null) {
                    return true;
                }
                if (done) {
                    return false;
                }
                try {
                    byte[] buffer = new byte[chunkSize];
                    int bytesRead = inputStream.read(buffer);
                    if (bytesRead == -1) {
                        done = true;
                        closeStream();
                        return false;
                    }
                    nextChunk = Arrays.copyOf(buffer, bytesRead);
                    return true;
                } catch (IOException e) {
                    closeStream();
                    throw new RuntimeException("Erreur de lecture du fichier pendant le découpage.", e);
                }
            }

            @Override
            public byte[] next() {
                if (!hasNext()) {
                    throw new NoSuchElementException("Plus de chunks à lire dans le fichier.");
                }
                byte[] chunkToReturn = nextChunk;
                nextChunk = null;
                return chunkToReturn;
            }
            
            private void closeStream() {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    // Ignorer les erreurs à la fermeture, le flux principal est déjà terminé ou en erreur.
                }
            }
        };
    }
}