package com.example.kafka.filetransfer;

import com.example.kafka.filetransfer.cli.ConsumerCommand;
import com.example.kafka.filetransfer.cli.ProducerCommand;
import picocli.CommandLine;
import picocli.CommandLine.Command;

/**
 * Point d'entrée principal de l'application de transfert de fichiers.
 * Utilise Picocli pour router les appels vers les sous-commandes appropriées
 * (producer, consumer).
 */
@Command(
    name = "file-transfer-app",
    mixinStandardHelpOptions = true,
    version = "File Transfer App 1.0",
    description = "Une application Kafka pour produire et consommer des fichiers de manière robuste.",
    // Enregistre les classes qui implémentent les sous-commandes
    subcommands = {
        ProducerCommand.class,
        ConsumerCommand.class,
        CommandLine.HelpCommand.class // Ajoute une commande "help" standard
    }
)
public class App {

    /**
     * La méthode main.
     * @param args Les arguments de la ligne de commande.
     */
    public static void main(String[] args) {
        // Picocli parse les arguments, exécute la bonne commande,
        // et retourne le code de sortie défini dans la méthode call() de la commande.
        int exitCode = new CommandLine(new App()).execute(args);
        
        // Termine l'application avec le code de sortie approprié,
        // ce qui permet de l'utiliser dans des scripts shell (via $?).
        System.exit(exitCode);
    }
}