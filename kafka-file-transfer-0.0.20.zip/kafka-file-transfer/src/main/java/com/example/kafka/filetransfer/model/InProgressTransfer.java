package com.example.kafka.filetransfer.model;

import com.example.kafka.filetransfer.proto.FileChunkMessage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Représente l'état d'un transfert en cours.
 * NE STOCKE PAS les données des chunks en mémoire. Au lieu de cela, il gère
 * un répertoire de transit sur le disque et suit la dernière activité pour
 * détecter les transferts abandonnés.
 */
public class InProgressTransfer {

    private final Path stagingDirectory;
    private final Set<Integer> receivedChunks = new HashSet<>();
    private FileChunkMessage finalChunkMetadata;
    
    // NOUVEAU: Timestamp de la dernière activité pour ce transfert.
    private long lastUpdateTime;

    /**
     * Crée un nouvel état de transfert en s'assurant que le répertoire de transit existe.
     * @param stagingDirectory Le répertoire unique pour ce transfert.
     * @throws IOException Si le répertoire ne peut pas être créé.
     */
    public InProgressTransfer(Path stagingDirectory) throws IOException {
        this.stagingDirectory = stagingDirectory;
        Files.createDirectories(stagingDirectory);
        // Initialiser le timestamp à la création.
        this.lastUpdateTime = System.currentTimeMillis();
    }

    /**
     * Ajoute les métadonnées d'un chunk à l'état du transfert et met à jour
     * le timestamp de dernière activité.
     * @param message Le message de chunk reçu.
     */
    public void addChunkMetadata(FileChunkMessage message) {
        // Mettre à jour le timestamp à chaque fois qu'un chunk (données ou final) est traité.
        this.lastUpdateTime = System.currentTimeMillis();

        if (message.getIsFinalChunk()) {
            this.finalChunkMetadata = message;
        } else {
            receivedChunks.add(message.getChunkNumber());
        }
    }

    /**
     * Vérifie si tous les chunks de données ont été reçus et si le chunk final
     * contenant les métadonnées est également arrivé.
     * @return true si le transfert est complet et prêt pour la reconstruction.
     */
    public boolean isComplete() {
        return finalChunkMetadata != null && receivedChunks.size() == finalChunkMetadata.getTotalChunks();
    }
    
    // NOUVEAU: Getter pour que le service de nettoyage puisse vérifier l'âge du transfert.
    public long getLastUpdateTime() {
        return lastUpdateTime;
    }

    public FileChunkMessage getFinalChunkMetadata() {
        return finalChunkMetadata;
    }

    public Path getStagingDirectory() {
        return stagingDirectory;
    }

    /**
     * Retourne la liste triée des chemins vers les fichiers de chunk sur le disque.
     * @return Une liste de Path triée par numéro de chunk.
     * @throws IOException Si une erreur de lecture du répertoire se produit.
     */
    public List<Path> getSortedChunkFiles() throws IOException {
        try (Stream<Path> paths = Files.list(stagingDirectory)) {
            return paths
                    .filter(p -> p.toString().endsWith(".chunk"))
                    .sorted(Comparator.comparingInt(p ->
                        Integer.parseInt(p.getFileName().toString().replace(".chunk", ""))))
                    .collect(Collectors.toList());
        }
    }
}