package com.example.kafka.filetransfer.kafka;

import com.example.kafka.filetransfer.model.TransferConfig;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.Future;

/**
 * MODIFIÉ: Service responsable de la publication de payloads (byte[]) sur le topic de données.
 */
public class KafkaChunkPublisher implements AutoCloseable {

    private static final Logger logger = LoggerFactory.getLogger(KafkaChunkPublisher.class);
    private final KafkaProducer<String, byte[]> producer;
    private final String dataTopic;

    public KafkaChunkPublisher(TransferConfig config) {
        this.producer = new KafkaProducer<>(config.getKafkaProducerProperties());
        this.dataTopic = config.getDataTopic();
    }

    /**
     * MODIFIÉ: Publie un payload de manière asynchrone.
     * @param transferId La clé du message Kafka.
     * @param payload Le message sérialisé (JSON ou Protobuf) à envoyer.
     * @param chunkDebugInfo Une information de contexte pour le log en cas d'erreur.
     */
    public void publish(String transferId, byte[] payload, String chunkDebugInfo) {
        ProducerRecord<String, byte[]> record = new ProducerRecord<>(dataTopic, transferId, payload);
        producer.send(record, (metadata, exception) -> {
            if (exception != null) {
                logger.error("Échec de l'envoi du chunk {} pour le transfert {}",
                        chunkDebugInfo, transferId, exception);
            }
        });
    }

    /**
     * MODIFIÉ: Publie un payload de manière synchrone (bloquant).
     * @param transferId La clé du message Kafka.
     * @param payload Le message sérialisé (JSON ou Protobuf) à envoyer.
     * @return Les métadonnées du message envoyé.
     */
    public Future<RecordMetadata> publishSync(String transferId, byte[] payload) {
        ProducerRecord<String, byte[]> record = new ProducerRecord<>(dataTopic, transferId, payload);
        Future<RecordMetadata> future = producer.send(record);

        // NOUVEAU: Log de l'offset pour les envois synchrones (utile pour le premier et le dernier message)
        try {
            RecordMetadata metadata = future.get(); // Attendre la confirmation
            logger.debug("Message synchrone publié avec succès -> {}-{}@{}",
                    metadata.topic(),
                    metadata.partition(),
                    metadata.offset());
        } catch (Exception e) {
            // L'exception sera gérée par l'appelant qui fait le .get()
        }
        return future;
    }

    @Override
    public void close() {
        if (producer != null) {
            producer.flush();
            producer.close();
            logger.debug("KafkaChunkPublisher fermé.");
        }
    }
}