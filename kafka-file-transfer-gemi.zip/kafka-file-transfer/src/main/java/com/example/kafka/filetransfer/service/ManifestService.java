package com.example.kafka.filetransfer.service;

import com.example.kafka.filetransfer.model.TransferConfig;
import com.example.kafka.filetransfer.proto.CompressionAlgorithm;
import com.example.kafka.filetransfer.proto.FileChunkMessage;
import com.example.kafka.filetransfer.proto.HashAlgorithm;
import com.google.protobuf.Int64Value;
import com.google.protobuf.StringValue;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.*;
import java.security.GeneralSecurityException;
import java.util.List;

/**
 * Service responsable de la gestion des métadonnées (le "manifeste") du fichier.
 */
public class ManifestService {

    private final TransferConfig config;

    // Constructeur pour le producteur
    public ManifestService() { this.config = null; }

    // Constructeur pour le consommateur
    public ManifestService(TransferConfig config) { this.config = config; }

    /**
     * Crée le builder de message Protobuf de base contenant toutes les métadonnées d'un fichier.
     * @param filePath Le chemin vers le fichier.
     * @param transferId L'ID unique du transfert.
     * @return Un builder pré-rempli avec les métadonnées.
     */
    public FileChunkMessage.Builder createManifest(Path filePath, String transferId) throws IOException {
        FileChunkMessage.Builder builder = FileChunkMessage.newBuilder();
        builder.setTransferId(transferId);
        builder.setFileName(filePath.getFileName().toString());

        // Attributs de base (multi-plateforme)
        BasicFileAttributes basicAttrs = Files.readAttributes(filePath, BasicFileAttributes.class);
        builder.setFileSize(basicAttrs.size());
        builder.setMtimeEpoch(basicAttrs.lastModifiedTime().toMillis());
        builder.setAtimeEpoch(basicAttrs.lastAccessTime().toMillis());
        if (basicAttrs.creationTime() != null) {
            builder.setBirthtimeEpoch(Int64Value.of(basicAttrs.creationTime().toMillis()));
        }

        // Attributs POSIX (Unix-like)
        if (FileSystems.getDefault().supportedFileAttributeViews().contains("posix")) {
            PosixFileAttributes posixAttrs = Files.readAttributes(filePath, PosixFileAttributes.class);
            builder.setOwnerName(StringValue.of(posixAttrs.owner().getName()));
            builder.setGroupName(StringValue.of(posixAttrs.group().getName()));
            builder.setPosixPermissions(StringValue.of(PosixFilePermissions.toString(posixAttrs.permissions())));
        }
        
        // --- Ajouter ici la lecture des ACL, xattr, etc. si nécessaire ---
        
        return builder;
    }

    /**
     * Applique les métadonnées contenues dans un message à un fichier physique.
     * @param filePath Le chemin vers le fichier à modifier.
     * @param metadata Le message contenant les métadonnées.
     */
    public void applyMetadata(Path filePath, FileChunkMessage metadata) throws IOException {
        if (config == null) throw new IllegalStateException("Le service doit être initialisé avec une configuration pour appliquer les métadonnées.");

        // Appliquer les timestamps
        if (config.shouldRestoreTimestamps()) {
            FileTime lastModifiedTime = FileTime.fromMillis(metadata.getMtimeEpoch());
            Files.setLastModifiedTime(filePath, lastModifiedTime);
        }

        boolean isPosix = FileSystems.getDefault().supportedFileAttributeViews().contains("posix");
        if (isPosix) {
            // Appliquer les permissions
            if (config.shouldRestorePermissions() && metadata.hasPosixPermissions()) {
                Files.setPosixFilePermissions(filePath, PosixFilePermissions.fromString(metadata.getPosixPermissions().getValue()));
            }

            // Appliquer le propriétaire/groupe (dangereux, nécessite des privilèges)
            if (config.shouldRestoreOwner() && metadata.hasOwnerName() && metadata.hasGroupName()) {
                try {
                    UserPrincipalLookupService lookupService = FileSystems.getDefault().getUserPrincipalLookupService();
                    UserPrincipal owner = lookupService.lookupPrincipalByName(metadata.getOwnerName().getValue());
                    GroupPrincipal group = lookupService.lookupPrincipalByGroupName(metadata.getGroupName().getValue());
                    Files.setOwner(filePath, owner);
                    Files.setAttribute(filePath, "posix:group", group);
                } catch (IOException e) {
                    System.err.println("AVERTISSEMENT: Impossible de définir le propriétaire/groupe. L'opération nécessite des privilèges élevés. Erreur : " + e.getMessage());
                }
            }
        }
    }
    
    /**
     * Écrit les chunks dans un fichier temporaire, en appliquant le déchiffrement et la décompression.
     */
    public void writeChunksToTempFile(Path tempPath, List<FileChunkMessage> chunks, CryptoService cryptoService, CompressionService compressionService) throws IOException, GeneralSecurityException {
        FileChunkMessage firstChunk = chunks.get(0); // On prend les métadonnées du premier chunk
        byte[] encryptedSymmetricKey = firstChunk.getEncryptedSymmetricKey().toByteArray();
        String cipherName = firstChunk.getEncryptionCipher().getValue();
        boolean isEncrypted = !firstChunk.getEncryptedSymmetricKey().isEmpty();

        try (OutputStream os = Files.newOutputStream(tempPath)) {
            for (FileChunkMessage chunk : chunks) {
                byte[] data = chunk.getData().toByteArray();

                // 1. Déchiffrer
                if (isEncrypted) {
                    data = cryptoService.decrypt(data, encryptedSymmetricKey, cipherName);
                }

                // 2. Décompresser
                CompressionAlgorithm compressionAlgo = chunk.getCompressionAlgorithm();
                data = compressionService.decompress(data, compressionAlgo.name(), chunk.getOriginalChunkSize());
                
                os.write(data);
            }
        }
    }
}