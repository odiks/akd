package com.example.kafka.filetransfer.producer;

import com.example.kafka.filetransfer.kafka.KafkaChunkPublisher;
import com.example.kafka.filetransfer.kafka.StatusReporter;
import com.example.kafka.filetransfer.model.TransferConfig;
import com.example.kafka.filetransfer.proto.FileChunkMessage;
import com.example.kafka.filetransfer.proto.StatusMessage;
import com.example.kafka.filetransfer.service.*;
import com.google.protobuf.ByteString;
// IMPORT AJOUTÉ
import com.google.protobuf.StringValue;

import java.nio.file.Path;
import java.util.Iterator;
import java.util.UUID;

public class FileTransferProducer {

    private final TransferConfig config;
    private final ManifestService manifestService;
    private final HashingService hashingService;
    private final CompressionService compressionService;
    private final CryptoService cryptoService;
    private final ChunkingService chunkingService;

    public FileTransferProducer(TransferConfig config) {
        this.config = config;
        this.manifestService = new ManifestService();
        this.hashingService = new HashingService();
        this.compressionService = new CompressionService();
        this.cryptoService = new CryptoService(config);
        this.chunkingService = new ChunkingService(config.getChunkSize());
    }

    public void startTransfer(Path filePath) throws Exception {
        String transferId = UUID.randomUUID().toString();

        try (KafkaChunkPublisher publisher = new KafkaChunkPublisher(config);
             StatusReporter statusReporter = new StatusReporter(config)) {

            statusReporter.report(transferId, StatusMessage.Status.TRANSFER_STARTED, "Démarrage du transfert pour " + filePath.getFileName());

            FileChunkMessage.Builder manifest = manifestService.createManifest(filePath, transferId);
            String fullFileHash = hashingService.calculateFileHash(filePath, config.getHashAlgorithm());
            manifest.setFileHash(fullFileHash);

            CryptoService.EncryptionResult encryptionResult = cryptoService.prepareEncryption();

            final int totalChunks = (int) Math.ceil((double) filePath.toFile().length() / config.getChunkSize());
            manifest.setTotalChunks(totalChunks);

            Iterator<byte[]> chunkIterator = chunkingService.iterateChunks(filePath);
            int chunkNumber = 0;
            while (chunkIterator.hasNext()) {
                chunkNumber++;
                byte[] chunkData = chunkIterator.next();
                
                String chunkHash = hashingService.calculateChunkHash(chunkData, config.getHashAlgorithm());
                byte[] processedData = processChunkData(chunkData, encryptionResult);

                FileChunkMessage chunkMessage = manifest.clone()
                        .setChunkNumber(chunkNumber)
                        .setChunkHash(chunkHash)
                        .setOriginalChunkSize(chunkData.length)
                        .setData(ByteString.copyFrom(processedData))
                        .build();

                publisher.publish(chunkMessage);
            }

            FileChunkMessage finalMessage = buildFinalMessage(manifest, encryptionResult);
            publisher.publishSync(finalMessage).get();

            statusReporter.report(transferId, StatusMessage.Status.TRANSFER_COMPLETED_PRODUCER, "Tous les chunks ont été envoyés.");
        }
    }

    private byte[] processChunkData(byte[] originalData, CryptoService.EncryptionResult encryptionResult) throws Exception {
        byte[] compressedData = compressionService.compress(originalData, config.getCompressionAlgorithm());
        return cryptoService.encrypt(compressedData, encryptionResult);
    }

    private FileChunkMessage buildFinalMessage(FileChunkMessage.Builder manifest, CryptoService.EncryptionResult encryptionResult) {
        if (encryptionResult.isEncrypted()) {
            manifest.setEncryptedSymmetricKey(ByteString.copyFrom(encryptionResult.getEncryptedSymmetricKey()));
            // CORRECTION: Envelopper le String dans un StringValue
            manifest.setEncryptionCipher(StringValue.of(encryptionResult.getCipherName()));
        }
        return manifest.setIsFinalChunk(true).build();
    }
}