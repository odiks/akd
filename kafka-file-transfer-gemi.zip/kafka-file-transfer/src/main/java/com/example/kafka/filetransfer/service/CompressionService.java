package com.example.kafka.filetransfer.service;

// Les imports corrects pour la librairie lz4-java.
import org.lz4.java.LZ4Compressor;
import org.lz4.java.LZ4Factory;
import org.lz4.java.LZ4FastDecompressor;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * Service responsable de la compression et de la décompression des chunks.
 */
public class CompressionService {

    private final LZ4Factory lz4Factory = LZ4Factory.fastestInstance();

    /**
     * Compresse un tableau d'octets en utilisant l'algorithme spécifié.
     * @param data Les données originales.
     * @param algorithm L'algorithme ("GZIP", "LZ4", "NONE").
     * @return Les données compressées.
     */
    public byte[] compress(byte[] data, String algorithm) throws IOException {
        switch (algorithm.toUpperCase()) {
            case "GZIP":
                return compressGzip(data);
            case "LZ4":
                return compressLz4(data);
            case "NONE":
            default:
                return data;
        }
    }

    /**
     * Décompresse un tableau d'octets en utilisant l'algorithme spécifié.
     * @param compressedData Les données compressées.
     * @param algorithm L'algorithme utilisé pour la compression.
     * @param originalLength La taille originale des données avant compression (important pour LZ4).
     * @return Les données décompressées.
     */
    public byte[] decompress(byte[] compressedData, String algorithm, int originalLength) throws IOException {
        switch (algorithm.toUpperCase()) {
            case "GZIP":
                return decompressGzip(compressedData);
            case "LZ4":
                return decompressLz4(compressedData, originalLength);
            case "NONE":
            default:
                return compressedData;
        }
    }

    private byte[] compressGzip(byte[] data) throws IOException {
        ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
        try (GZIPOutputStream gzipStream = new GZIPOutputStream(byteStream)) {
            gzipStream.write(data);
        }
        return byteStream.toByteArray();
    }

    private byte[] decompressGzip(byte[] compressedData) throws IOException {
        ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
        try (GZIPInputStream gzipStream = new GZIPInputStream(new ByteArrayInputStream(compressedData))) {
            gzipStream.transferTo(byteStream);
        }
        return byteStream.toByteArray();
    }

    private byte[] compressLz4(byte[] data) {
        LZ4Compressor compressor = lz4Factory.fastCompressor();
        return compressor.compress(data);
    }

    private byte[] decompressLz4(byte[] compressedData, int originalLength) {
        LZ4FastDecompressor decompressor = lz4Factory.fastDecompressor();
        byte[] restored = new byte[originalLength];
        decompressor.decompress(compressedData, 0, restored, 0, originalLength);
        return restored;
    }
}