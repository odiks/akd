package com.example.kafka.filetransfer.model;

import com.example.kafka.filetransfer.proto.FileChunkMessage;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * Représente l'état d'un transfert de fichier en cours côté consommateur.
 * Stocke les chunks reçus en attendant que le transfert soit complet.
 */
public class InProgressTransfer {

    private final Map<Integer, FileChunkMessage> chunks = new ConcurrentHashMap<>();
    private FileChunkMessage finalChunkMetadata;
    private boolean finalChunkReceived = false;

    public void addChunk(FileChunkMessage message) {
        if (message.getIsFinalChunk()) {
            this.finalChunkMetadata = message;
            this.finalChunkReceived = true;
        } else {
            chunks.put(message.getChunkNumber(), message);
        }
    }

    public boolean isComplete() {
        return finalChunkReceived && chunks.size() == finalChunkMetadata.getTotalChunks();
    }

    public FileChunkMessage getFinalChunkMetadata() {
        return finalChunkMetadata;
    }

    public List<FileChunkMessage> getSortedChunks() {
        return new ArrayList<>(chunks.values())
                .stream()
                .sorted(Comparator.comparingInt(FileChunkMessage::getChunkNumber))
                .collect(Collectors.toList());
    }
}