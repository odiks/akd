package com.example.kafka.filetransfer.model;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.ByteArrayDeserializer;
import org.apache.kafka.common.serialization.ByteArraySerializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.Properties;

/**
 * Un objet de configuration type-safe qui parse les propriétés et les expose via des getters.
 * Centralise la logique de configuration.
 */
public class TransferConfig {

    private final Properties props;

    public TransferConfig(Properties props) {
        this.props = props;
        validate();
    }

    private void validate() {
        if (props.getProperty("bootstrap.servers") == null) {
            throw new IllegalArgumentException("La propriété 'bootstrap.servers' est requise.");
        }
        if (props.getProperty("topic.data") == null) {
            throw new IllegalArgumentException("La propriété 'topic.data' est requise.");
        }
    }

    // --- Getters de configuration générale ---
    public String getDataTopic() { return props.getProperty("topic.data"); }
    public String getStatusTopic() { return props.getProperty("topic.status", "files-status-topic"); }
    public int getChunkSize() { return Integer.parseInt(props.getProperty("chunk.size", "1048576")); }
    public String getHashAlgorithm() { return props.getProperty("hash.algorithm", "SHA-256"); }
    public String getCompressionAlgorithm() { return props.getProperty("compression.algorithm", "NONE"); }
    
    // --- Getters de configuration de sécurité ---
    public boolean isEncryptionEnabled() { return Boolean.parseBoolean(props.getProperty("encryption.enabled", "false")); }
    public String getConsumerPublicKeyPath() { return props.getProperty("encryption.consumer.public_key.path"); }
    public String getConsumerPrivateKeyPath() { return props.getProperty("encryption.private_key.path"); }

    // --- Getters de configuration de métadonnées (côté consumer) ---
    public boolean shouldRestorePermissions() { return Boolean.parseBoolean(props.getProperty("metadata.restore.permissions", "true")); }
    public boolean shouldRestoreOwner() { return Boolean.parseBoolean(props.getProperty("metadata.restore.owner", "false")); }
    public boolean shouldRestoreTimestamps() { return Boolean.parseBoolean(props.getProperty("metadata.restore.timestamps", "true")); }

    /**
     * Construit un objet Properties pour un KafkaProducer.
     * @return Properties configurées pour le producteur.
     */
    public Properties getKafkaProducerProperties() {
        Properties kafkaProps = new Properties();
        kafkaProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, props.getProperty("bootstrap.servers"));
        kafkaProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        kafkaProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, ByteArraySerializer.class.getName());
        kafkaProps.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, props.getProperty("enable.idempotence", "true"));
        kafkaProps.put(ProducerConfig.ACKS_CONFIG, props.getProperty("acks", "all"));
        kafkaProps.put(ProducerConfig.RETRIES_CONFIG, props.getProperty("retries", "5"));
        return kafkaProps;
    }

    /**
     * Construit un objet Properties pour un KafkaConsumer.
     * @return Properties configurées pour le consommateur.
     */
    public Properties getKafkaConsumerProperties() {
        Properties kafkaProps = new Properties();
        kafkaProps.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, props.getProperty("bootstrap.servers"));
        kafkaProps.put(ConsumerConfig.GROUP_ID_CONFIG, props.getProperty("group.id"));
        kafkaProps.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        kafkaProps.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, ByteArrayDeserializer.class.getName());
        kafkaProps.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        kafkaProps.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        return kafkaProps;
    }
}