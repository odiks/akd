package com.example.kafka.filetransfer.cli;

import com.example.kafka.filetransfer.ErrorCode;
import com.example.kafka.filetransfer.model.TransferConfig;
import com.example.kafka.filetransfer.producer.FileTransferProducer;
import org.apache.kafka.common.KafkaException;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;
import picocli.CommandLine.Parameters;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Properties;
import java.util.concurrent.Callable;

/**
 * Commande Picocli pour le producteur.
 * Gère le parsing des arguments de la ligne de commande et orchestre le démarrage du transfert de fichier.
 */
@Command(name = "producer",
         mixinStandardHelpOptions = true,
         description = "Lit un fichier, le découpe en chunks, et l'envoie vers un topic Kafka.")
public class ProducerCommand implements Callable<Integer> {

    @Parameters(index = "0", description = "Le chemin complet du fichier à envoyer.")
    private File file;

    @Option(names = {"-c", "--config"}, required = true, description = "Chemin vers le fichier de propriétés du producteur.")
    private File configFile;

    @Override
    public Integer call() {
        // 1. Validation initiale des arguments
        if (!Files.exists(file.toPath())) {
            System.err.printf("Erreur de validation : Le fichier '%s' n'existe pas.%n", file.getAbsolutePath());
            return ErrorCode.VALIDATION_ERROR.getCode();
        }
        if (!Files.isReadable(file.toPath())) {
            System.err.printf("Erreur d'IO : Le fichier '%s' n'est pas lisible.%n", file.getAbsolutePath());
            return ErrorCode.IO_ERROR.getCode();
        }

        // 2. Chargement de la configuration
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(configFile)) {
            props.load(fis);
        } catch (FileNotFoundException e) {
            System.err.printf("Erreur de configuration : Le fichier de propriétés '%s' est introuvable.%n", configFile.getAbsolutePath());
            return ErrorCode.CONFIG_ERROR.getCode();
        } catch (IOException e) {
            System.err.printf("Erreur d'IO : Impossible de lire le fichier de propriétés '%s'.%n", configFile.getAbsolutePath());
            return ErrorCode.IO_ERROR.getCode();
        }

        // 3. Exécution du processus métier
        try {
            TransferConfig transferConfig = new TransferConfig(props);
            FileTransferProducer producer = new FileTransferProducer(transferConfig);
            producer.startTransfer(file.toPath());
            
            System.out.println("Transfert du fichier initié et terminé avec succès côté producteur.");
            return ErrorCode.OK.getCode();

        } catch (IllegalArgumentException e) {
            System.err.printf("Erreur de configuration : %s%n", e.getMessage());
            return ErrorCode.CONFIG_ERROR.getCode();
        } catch (KafkaException e) {
            System.err.printf("Erreur Kafka : %s. Vérifiez la connexion aux brokers. Détails : %s%n", ErrorCode.KAFKA_ERROR.getDescription(), e.getMessage());
            return ErrorCode.KAFKA_ERROR.getCode();
        } catch (Exception e) {
            System.err.printf("Erreur Inconnue : %s. Détails : %s%n", ErrorCode.UNKNOWN.getDescription(), e.getMessage());
            e.printStackTrace(System.err);
            return ErrorCode.UNKNOWN.getCode();
        }
    }
}