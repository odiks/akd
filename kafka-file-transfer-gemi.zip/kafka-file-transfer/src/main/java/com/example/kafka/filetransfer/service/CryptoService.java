package com.example.kafka.filetransfer.service;

import com.example.kafka.filetransfer.model.TransferConfig;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

/**
 * Service gérant toutes les opérations cryptographiques.
 * Implémente un chiffrement hybride RSA/AES.
 */
public class CryptoService {

    private static final String RSA_TRANSFORMATION = "RSA/ECB/PKCS1Padding";
    private static final String AES_TRANSFORMATION = "AES/GCM/NoPadding";
    private static final String AES_ALGORITHM = "AES";

    private final TransferConfig config;
    private final PrivateKey consumerPrivateKey;

    public CryptoService(TransferConfig config) {
        this.config = config;
        // Pré-charger la clé privée si disponible (côté consommateur)
        if (config.getConsumerPrivateKeyPath() != null) {
            try {
                this.consumerPrivateKey = loadPrivateKey(config.getConsumerPrivateKeyPath());
            } catch (Exception e) {
                throw new IllegalArgumentException("Impossible de charger la clé privée depuis " + config.getConsumerPrivateKeyPath(), e);
            }
        } else {
            this.consumerPrivateKey = null;
        }
    }

    // --- Méthodes côté Producteur ---

    public EncryptionResult prepareEncryption() throws GeneralSecurityException, IOException {
        if (!config.isEncryptionEnabled()) {
            return EncryptionResult.unencrypted();
        }

        // 1. Générer une clé symétrique (AES) à usage unique
        KeyGenerator keyGen = KeyGenerator.getInstance(AES_ALGORITHM);
        keyGen.init(256);
        SecretKey aesKey = keyGen.generateKey();

        // 2. Charger la clé publique RSA du consommateur
        PublicKey rsaPublicKey = loadPublicKey(config.getConsumerPublicKeyPath());

        // 3. Chiffrer la clé AES avec la clé publique RSA
        Cipher rsaCipher = Cipher.getInstance(RSA_TRANSFORMATION);
        rsaCipher.init(Cipher.ENCRYPT_MODE, rsaPublicKey);
        byte[] encryptedAesKey = rsaCipher.doFinal(aesKey.getEncoded());

        return EncryptionResult.encrypted(aesKey, encryptedAesKey, AES_TRANSFORMATION);
    }

    public byte[] encrypt(byte[] data, EncryptionResult result) throws GeneralSecurityException {
        if (!result.isEncrypted()) {
            return data;
        }
        // NOTE: Une implémentation de production DOIT gérer l'IV (Initialization Vector) de GCM.
        // L'IV doit être unique pour chaque chiffrement avec la même clé.
        // Il est généralement préfixé au ciphertext.
        Cipher aesCipher = Cipher.getInstance(result.getCipherName());
        aesCipher.init(Cipher.ENCRYPT_MODE, result.getSymmetricKey());
        return aesCipher.doFinal(data);
    }

    // --- Méthode côté Consommateur ---

    public byte[] decrypt(byte[] encryptedData, byte[] encryptedSymmetricKey, String cipherName) throws GeneralSecurityException {
        if (consumerPrivateKey == null) {
            throw new GeneralSecurityException("Clé privée du consommateur non disponible pour le déchiffrement.");
        }

        // 1. Déchiffrer la clé symétrique avec notre clé privée RSA
        Cipher rsaCipher = Cipher.getInstance(RSA_TRANSFORMATION);
        rsaCipher.init(Cipher.DECRYPT_MODE, consumerPrivateKey);
        byte[] decryptedAesKeyBytes = rsaCipher.doFinal(encryptedSymmetricKey);
        SecretKey aesKey = new SecretKeySpec(decryptedAesKeyBytes, 0, decryptedAesKeyBytes.length, AES_ALGORITHM);

        // 2. Déchiffrer les données avec la clé AES
        Cipher aesCipher = Cipher.getInstance(cipherName);
        aesCipher.init(Cipher.DECRYPT_MODE, aesKey); // IV manquant ici. Voir la note ci-dessus.
        return aesCipher.doFinal(encryptedData);
    }

    // --- Utilitaires de chargement de clés ---

    private PublicKey loadPublicKey(String path) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
        byte[] keyBytes = Files.readAllBytes(Paths.get(path));
        String keyString = new String(keyBytes)
                .replace("-----BEGIN PUBLIC KEY-----", "")
                .replaceAll("\\R", "")
                .replace("-----END PUBLIC KEY-----", "");
        byte[] decoded = Base64.getDecoder().decode(keyString);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return keyFactory.generatePublic(new X509EncodedKeySpec(decoded));
    }

    private PrivateKey loadPrivateKey(String path) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
        byte[] keyBytes = Files.readAllBytes(Paths.get(path));
        String keyString = new String(keyBytes)
                .replace("-----BEGIN PRIVATE KEY-----", "")
                .replaceAll("\\R", "")
                .replace("-----END PRIVATE KEY-----", "");
        byte[] decoded = Base64.getDecoder().decode(keyString);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return keyFactory.generatePrivate(new PKCS8EncodedKeySpec(decoded));
    }

    /**
     * Classe interne pour encapsuler le résultat de la préparation du chiffrement.
     */
    public static class EncryptionResult {
        private final boolean encrypted;
        private final SecretKey symmetricKey;
        private final byte[] encryptedSymmetricKey;
        private final String cipherName;

        private EncryptionResult(boolean encrypted, SecretKey key, byte[] encryptedKey, String cipher) {
            this.encrypted = encrypted;
            this.symmetricKey = key;
            this.encryptedSymmetricKey = encryptedKey;
            this.cipherName = cipher;
        }

        public static EncryptionResult unencrypted() {
            return new EncryptionResult(false, null, null, null);
        }

        public static EncryptionResult encrypted(SecretKey key, byte[] encryptedKey, String cipher) {
            return new EncryptionResult(true, key, encryptedKey, cipher);
        }

        public boolean isEncrypted() { return encrypted; }
        public SecretKey getSymmetricKey() { return symmetricKey; }
        public byte[] getEncryptedSymmetricKey() { return encryptedSymmetricKey; }
        public String getCipherName() { return cipherName; }
    }
}