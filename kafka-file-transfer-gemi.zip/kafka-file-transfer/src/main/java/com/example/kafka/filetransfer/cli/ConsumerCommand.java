package com.example.kafka.filetransfer.cli;

import com.example.kafka.filetransfer.ErrorCode;
import com.example.kafka.filetransfer.consumer.FileTransferConsumer;
import com.example.kafka.filetransfer.model.TransferConfig;
import org.apache.kafka.common.errors.InterruptException;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.Callable;

/**
 * Commande Picocli pour le consommateur.
 * Gère le parsing des arguments et lance le processus d'écoute et de reconstruction de fichiers.
 */
@Command(name = "consumer",
         mixinStandardHelpOptions = true,
         description = "Écoute un topic Kafka, assemble les chunks et reconstruit les fichiers.")
public class ConsumerCommand implements Callable<Integer> {

    @Option(names = {"-d", "--destination-dir"}, required = true, description = "Répertoire de destination pour les fichiers reconstruits.")
    private File destinationDir;

    @Option(names = {"-c", "--config"}, required = true, description = "Chemin vers le fichier de propriétés du consommateur.")
    private File configFile;

    @Override
    public Integer call() {
        // 1. Validation initiale des arguments
        if (!destinationDir.exists() || !destinationDir.isDirectory()) {
            System.err.printf("Erreur de validation : Le répertoire de destination '%s' n'existe pas ou n'est pas un répertoire.%n", destinationDir.getAbsolutePath());
            return ErrorCode.VALIDATION_ERROR.getCode();
        }
        if (!destinationDir.canWrite()) {
            System.err.printf("Erreur d'IO : Impossible d'écrire dans le répertoire de destination '%s'.%n", destinationDir.getAbsolutePath());
            return ErrorCode.IO_ERROR.getCode();
        }

        // 2. Chargement de la configuration
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(configFile)) {
            props.load(fis);
        } catch (FileNotFoundException e) {
            System.err.printf("Erreur de configuration : Le fichier de propriétés '%s' est introuvable.%n", configFile.getAbsolutePath());
            return ErrorCode.CONFIG_ERROR.getCode();
        } catch (IOException e) {
            System.err.printf("Erreur d'IO : Impossible de lire le fichier de propriétés '%s'.%n", configFile.getAbsolutePath());
            return ErrorCode.IO_ERROR.getCode();
        }
        
        // 3. Lancement du processus d'écoute (boucle infinie)
        try {
            TransferConfig transferConfig = new TransferConfig(props);
            FileTransferConsumer consumer = new FileTransferConsumer(transferConfig, destinationDir.toPath());
            
            // Ajout d'un "Shutdown Hook" pour une fermeture propre sur Ctrl+C
            Runtime.getRuntime().addShutdownHook(new Thread(consumer::shutdown));
            
            consumer.start(); // Cette méthode est bloquante et ne retourne que sur erreur ou interruption.
            
            return ErrorCode.OK.getCode();
        } catch (IllegalArgumentException e) {
            System.err.printf("Erreur de configuration : %s%n", e.getMessage());
            return ErrorCode.CONFIG_ERROR.getCode();
        } catch (InterruptException e) {
            System.out.println("\nProcessus consommateur interrompu. Fermeture.");
            return ErrorCode.OK.getCode();
        } catch (Exception e) {
            System.err.printf("Erreur Inconnue critique dans le consommateur : %s. Détails : %s%n", ErrorCode.UNKNOWN.getDescription(), e.getMessage());
            e.printStackTrace(System.err);
            return ErrorCode.UNKNOWN.getCode();
        }
    }
}