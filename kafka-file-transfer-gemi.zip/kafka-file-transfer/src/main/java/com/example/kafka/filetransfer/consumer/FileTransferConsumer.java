package com.example.kafka.filetransfer.consumer;

import com.example.kafka.filetransfer.model.InProgressTransfer;
import com.example.kafka.filetransfer.kafka.StatusReporter;
import com.example.kafka.filetransfer.model.TransferConfig;
import com.example.kafka.filetransfer.proto.FileChunkMessage;
import com.example.kafka.filetransfer.proto.StatusMessage;
import com.example.kafka.filetransfer.service.*;
import com.google.protobuf.InvalidProtocolBufferException;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.InterruptException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.GeneralSecurityException;
import java.time.Duration;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;


public class FileTransferConsumer {

    private static final Logger logger = LoggerFactory.getLogger(FileTransferConsumer.class);

    private final TransferConfig config;
    private final Path destinationDir;
    private final KafkaConsumer<String, byte[]> kafkaConsumer;
    private final Map<String, InProgressTransfer> inProgressTransfers = new ConcurrentHashMap<>();
    private final AtomicBoolean running = new AtomicBoolean(true);

    // Services
    private final StatusReporter statusReporter;
    private final CryptoService cryptoService;
    private final CompressionService compressionService;
    private final HashingService hashingService;
    private final ManifestService manifestService;


    public FileTransferConsumer(TransferConfig config, Path destinationDir) {
        this.config = config;
        this.destinationDir = destinationDir;
        this.kafkaConsumer = new KafkaConsumer<>(config.getKafkaConsumerProperties());
        
        // Initialisation des services
        this.statusReporter = new StatusReporter(config);
        this.cryptoService = new CryptoService(config);
        this.compressionService = new CompressionService();
        this.hashingService = new HashingService();
        this.manifestService = new ManifestService(config);
    }

    
    public void start() {
        kafkaConsumer.subscribe(Collections.singletonList(config.getDataTopic()));
        logger.info("Consommateur démarré. En écoute sur le topic '{}'", config.getDataTopic());

        try {
            while (running.get()) {
                ConsumerRecords<String, byte[]> records = kafkaConsumer.poll(Duration.ofMillis(500));
                for (ConsumerRecord<String, byte[]> record : records) {
                    processRecord(record);
                }
                if (!records.isEmpty()) {
                    kafkaConsumer.commitSync();
                }
            }
        } catch (InterruptException e) {
            logger.warn("Boucle du consommateur interrompue.");
            throw e;
        } finally {
            close();
        }
    }

    private void processRecord(ConsumerRecord<String, byte[]> record) {
        try {
            FileChunkMessage message = FileChunkMessage.parseFrom(record.value());
            String transferId = message.getTransferId();

            // CORRECTION ICI: Syntaxe correcte pour une référence de constructeur dans computeIfAbsent
            InProgressTransfer transfer = inProgressTransfers.computeIfAbsent(transferId, k -> new InProgressTransfer());
            transfer.addChunk(message);

            if (transfer.isComplete()) {
                logger.info("Transfert '{}' complet. Démarrage de la reconstruction pour le fichier '{}'.", transferId, message.getFileName());
                reconstructFile(transfer);
                inProgressTransfers.remove(transferId); // Nettoyage de la mémoire
            }

        } catch (InvalidProtocolBufferException e) {
            logger.error("Impossible de désérialiser le message Protobuf. Offset: {}, Partition: {}. Message ignoré.", record.offset(), record.partition(), e);
        }
    }
    
    private void reconstructFile(InProgressTransfer transfer) {
        FileChunkMessage metadata = transfer.getFinalChunkMetadata();
        String transferId = metadata.getTransferId();
        String fileName = metadata.getFileName();
        Path finalPath = destinationDir.resolve(fileName);
        Path tempPath = Paths.get(finalPath + "." + transferId + ".tmp");

        try {
            statusReporter.report(transferId, StatusMessage.Status.RECONSTRUCTION_STARTED, "Reconstruction démarrée pour " + fileName);
            
            manifestService.writeChunksToTempFile(tempPath, transfer.getSortedChunks(), cryptoService, compressionService);

            hashingService.verifyFileIntegrity(tempPath, metadata.getFileHash(), metadata.getHashAlgorithm());
            logger.info("Vérification d'intégrité réussie pour le transfert '{}'.", transferId);

            manifestService.applyMetadata(tempPath, metadata);
            logger.info("Application des métadonnées réussie pour le transfert '{}'.", transferId);

            Files.move(tempPath, finalPath, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            logger.info("Fichier '{}' reconstruit avec succès à l'emplacement : {}", fileName, finalPath);

            statusReporter.report(transferId, StatusMessage.Status.RECONSTRUCTION_SUCCESS, "Fichier reconstruit avec succès à " + finalPath);

        } catch (IOException | GeneralSecurityException e) {
            logger.error("Erreur critique durant la reconstruction du fichier pour le transfert '{}'.", transferId, e);
            statusReporter.report(transferId, StatusMessage.Status.TRANSFER_FAILED, "Erreur de reconstruction : " + e.getMessage());
            cleanupFailedTransfer(tempPath);
        } catch (SecurityException e) {
             logger.error("Échec de la vérification d'intégrité pour le transfert '{}' !", transferId, e);
             statusReporter.report(transferId, StatusMessage.Status.TRANSFER_FAILED, "ÉCHEC INTÉGRITÉ : " + e.getMessage());
             cleanupFailedTransfer(tempPath);
        }
    }

    private void cleanupFailedTransfer(Path tempFile) {
        try {
            if (Files.exists(tempFile)) {
                Files.delete(tempFile);
                logger.info("Fichier temporaire '{}' nettoyé après échec.", tempFile);
            }
        } catch (IOException ex) {
            logger.error("Impossible de supprimer le fichier temporaire '{}' après un échec.", tempFile, ex);
        }
    }

    public void shutdown() {
        running.set(false);
    }
    
    private void close() {
        if (kafkaConsumer != null) {
            kafkaConsumer.close();
        }
        if (statusReporter != null) {
            statusReporter.close();
        }
        logger.info("Ressources du consommateur fermées.");
    }
}