package com.example.kafka.filetransfer.service;

import com.example.kafka.filetransfer.model.TransferConfig;
import com.example.kafka.filetransfer.proto.AclEntry;
import com.example.kafka.filetransfer.proto.FileChunkMessage;
import com.google.protobuf.Int64Value;
import com.google.protobuf.StringValue;
import org.slf4j.Logger;         // <-- IMPORT AJOUTÉ
import org.slf4j.LoggerFactory; // <-- IMPORT AJOUTÉ

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class ManifestService {

    // <-- DÉCLARATION DU LOGGER AJOUTÉE
    private static final Logger logger = LoggerFactory.getLogger(ManifestService.class);
    
    private final TransferConfig config;

    public ManifestService() { this.config = null; }
    public ManifestService(TransferConfig config) { this.config = config; }

    /**
     * Crée le "manifeste" de base pour un transfert.
     * @param filePath Le chemin vers le fichier.
     * @param transferId L'ID de transfert unique fourni par l'appelant.
     * @return Un builder FileChunkMessage pré-rempli.
     * @throws IOException Si la lecture des attributs du fichier échoue.
     */
    public FileChunkMessage.Builder createManifest(Path filePath, String transferId) throws IOException {
        FileChunkMessage.Builder builder = FileChunkMessage.newBuilder();
        builder.setTransferId(transferId);
        builder.setFileName(filePath.getFileName().toString());

        try {
            builder.setSourceHostname(StringValue.of(InetAddress.getLocalHost().getHostName()));
        } catch (UnknownHostException e) {
            builder.setSourceHostname(StringValue.of("unknown-host"));
        }
        builder.setSourceUsername(StringValue.of(System.getProperty("user.name")));

        BasicFileAttributes basicAttrs = Files.readAttributes(filePath, BasicFileAttributes.class);
        builder.setFileSize(basicAttrs.size());
        builder.setMtimeEpoch(basicAttrs.lastModifiedTime().toMillis());
        builder.setAtimeEpoch(basicAttrs.lastAccessTime().toMillis());
        if (basicAttrs.creationTime() != null) {
            builder.setBirthtimeEpoch(Int64Value.of(basicAttrs.creationTime().toMillis()));
        }

        if (FileSystems.getDefault().supportedFileAttributeViews().contains("posix")) {
            PosixFileAttributes posixAttrs = Files.readAttributes(filePath, PosixFileAttributes.class);
            builder.setOwnerName(StringValue.of(posixAttrs.owner().getName()));
            builder.setGroupName(StringValue.of(posixAttrs.group().getName()));
            builder.setPosixPermissions(StringValue.of(PosixFilePermissions.toString(posixAttrs.permissions())));
        }

        AclFileAttributeView aclView = Files.getFileAttributeView(filePath, AclFileAttributeView.class);
        if (aclView != null) {
            for (java.nio.file.attribute.AclEntry entry : aclView.getAcl()) {
                AclEntry.Builder protoAclEntry = AclEntry.newBuilder()
                        .setType(entry.type().name())
                        .setPrincipal(entry.principal().getName());
                for (AclEntryPermission perm : entry.permissions()) { protoAclEntry.addPermissions(perm.name()); }
                for (AclEntryFlag flag : entry.flags()) { protoAclEntry.addFlags(flag.name()); }
                builder.addWindowsAcls(protoAclEntry.build());
            }
        }
        return builder;
    }

    /**
     * Applique les métadonnées d'un manifeste à un fichier reconstruit.
     * @param filePath Le chemin vers le fichier.
     * @param metadata Le message contenant les métadonnées à appliquer.
     * @throws IOException Si l'écriture des attributs échoue.
     */
    public void applyMetadata(Path filePath, FileChunkMessage metadata) throws IOException {
        if (config == null) throw new IllegalStateException("Le service doit être initialisé avec une configuration pour appliquer les métadonnées.");
        if (config.shouldRestoreTimestamps()) Files.setLastModifiedTime(filePath, FileTime.fromMillis(metadata.getMtimeEpoch()));
        AclFileAttributeView aclView = Files.getFileAttributeView(filePath, AclFileAttributeView.class);
        if (!metadata.getWindowsAclsList().isEmpty() && aclView != null) applyWindowsAcls(filePath, metadata, aclView);
        else if (FileSystems.getDefault().supportedFileAttributeViews().contains("posix")) applyPosixPermissions(filePath, metadata);
    }

    private void applyPosixPermissions(Path filePath, FileChunkMessage metadata) throws IOException {
        if (config.shouldRestorePermissions() && metadata.hasPosixPermissions()) Files.setPosixFilePermissions(filePath, PosixFilePermissions.fromString(metadata.getPosixPermissions().getValue()));
        if (config.shouldRestoreOwner() && metadata.hasOwnerName() && metadata.hasGroupName()) {
            try {
                UserPrincipalLookupService lookupService = FileSystems.getDefault().getUserPrincipalLookupService();
                UserPrincipal owner = lookupService.lookupPrincipalByName(metadata.getOwnerName().getValue());
                GroupPrincipal group = lookupService.lookupPrincipalByGroupName(metadata.getGroupName().getValue());
                Files.setOwner(filePath, owner);
                Files.setAttribute(filePath, "posix:group", group);
            } catch (IOException e) {
                // <-- System.err REMPLACÉ PAR logger.warn
                logger.warn("Impossible de définir le propriétaire/groupe POSIX. Détails: {}", e.getMessage());
            }
        }
    }

    private void applyWindowsAcls(Path filePath, FileChunkMessage metadata, AclFileAttributeView aclView) throws IOException {
        UserPrincipalLookupService lookupService = filePath.getFileSystem().getUserPrincipalLookupService();
        List<java.nio.file.attribute.AclEntry> newAclList = new ArrayList<>();
        for (AclEntry protoAcl : metadata.getWindowsAclsList()) {
            try {
                UserPrincipal principal = lookupService.lookupPrincipalByName(protoAcl.getPrincipal());
                java.nio.file.attribute.AclEntry.Builder aclEntryBuilder = java.nio.file.attribute.AclEntry.newBuilder().setType(AclEntryType.valueOf(protoAcl.getType())).setPrincipal(principal);
                Set<AclEntryPermission> perms = protoAcl.getPermissionsList().stream().map(AclEntryPermission::valueOf).collect(Collectors.toSet());
                Set<AclEntryFlag> flags = protoAcl.getFlagsList().stream().map(AclEntryFlag::valueOf).collect(Collectors.toSet());
                aclEntryBuilder.setPermissions(perms);
                aclEntryBuilder.setFlags(flags);
                newAclList.add(aclEntryBuilder.build());
            } catch (UserPrincipalNotFoundException | IllegalArgumentException e) {
                // <-- System.err REMPLACÉ PAR logger.warn
                logger.warn("Impossible de résoudre le principal '{}' ou une permission/flag sur le système destination. L'entrée ACL est ignorée.", protoAcl.getPrincipal());
            }
        }
        if (!newAclList.isEmpty()) aclView.setAcl(newAclList);
    }
}