package com.example.kafkafs;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import net.jpountz.lz4.LZ4Compressor;
import net.jpountz.lz4.LZ4Factory;
import net.jpountz.lz4.LZ4FastDecompressor;

public class CompressionUtil {
    public static byte[] compress(byte[] data, Options.Compression c) throws IOException {
        return switch (c) {
            case NONE -> data;
            case GZIP -> gzip(data);
            case LZ4 -> lz4(data);
        };
    }
    public static byte[] decompress(byte[] data, Options.Compression c) throws IOException {
        return switch (c) {
            case NONE -> data;
            case GZIP -> gunzip(data);
            case LZ4 -> unlz4(data);
        };
    }
    private static byte[] gzip(byte[] data) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (GZIPOutputStream gos = new GZIPOutputStream(baos)) {
            gos.write(data);
        }
        return baos.toByteArray();
    }
    private static byte[] gunzip(byte[] data) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (GZIPInputStream gis = new GZIPInputStream(new ByteArrayInputStream(data))) {
            gis.transferTo(baos);
        }
        return baos.toByteArray();
    }
    private static byte[] lz4(byte[] data) {
        LZ4Compressor c = LZ4Factory.fastestInstance().fastCompressor();
        int max = c.maxCompressedLength(data.length);
        byte[] out = new byte[max + 4];
        // store original length in first 4 bytes (big endian) for decompression
        out[0]=(byte)((data.length>>>24)&0xff);
        out[1]=(byte)((data.length>>>16)&0xff);
        out[2]=(byte)((data.length>>>8)&0xff);
        out[3]=(byte)(data.length&0xff);
        int comp = c.compress(data, 0, data.length, out, 4, max);
        byte[] ret = new byte[4+comp];
        System.arraycopy(out, 0, ret, 0, ret.length);
        return ret;
    }
    private static byte[] unlz4(byte[] data) {
        int origLen = ((data[0]&0xff)<<24)|((data[1]&0xff)<<16)|((data[2]&0xff)<<8)|(data[3]&0xff);
        byte[] restored = new byte[origLen];
        LZ4FastDecompressor d = LZ4Factory.fastestInstance().fastDecompressor();
        d.decompress(data, 4, restored, 0, origLen);
        return restored;
    }
}
