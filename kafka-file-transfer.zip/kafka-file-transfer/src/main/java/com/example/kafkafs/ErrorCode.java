package com.example.kafkafs;

public enum ErrorCode {
    OK(0),
    CONFIG_ERROR(10),
    IO_ERROR(20),
    KAFKA_ERROR(30),
    CRYPTO_ERROR(40),
    INTEGRITY_FAILED(50),
    TIMEOUT(60),
    INTERRUPTED(70),
    VALIDATION_ERROR(80),
    UNKNOWN(90);

    private final int code;
    ErrorCode(int code){ this.code = code; }
    public int code(){ return code; }
}
