package com.example.kafkafs;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.security.*;
import java.security.spec.MGF1ParameterSpec;
import java.security.spec.PSSParameterSpec;
import java.util.Arrays;
import java.util.Base64;

public class CryptoUtil {

    public record EncResult(byte[] iv, byte[] ciphertext, byte[] wrappedKey) {}

    public static EncResult encryptAesGcmRsaOaep(byte[] data, PublicKey rsaPublic) throws Exception {
        KeyGenerator kg = KeyGenerator.getInstance("AES");
        kg.init(256);
        SecretKey aes = kg.generateKey();
        byte[] iv = SecureRandom.getInstanceStrong().generateSeed(12);

        Cipher aesCipher = Cipher.getInstance("AES/GCM/NoPadding");
        aesCipher.init(Cipher.ENCRYPT_MODE, aes, new GCMParameterSpec(128, iv));
        byte[] ct = aesCipher.doFinal(data);

        Cipher rsa = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
        rsa.init(Cipher.WRAP_MODE, rsaPublic);
        byte[] wrapped = rsa.wrap(aes);

        return new EncResult(iv, ct, wrapped);
    }

    public static byte[] decryptAesGcmRsaOaep(byte[] iv, byte[] ciphertext, byte[] wrappedKey, PrivateKey rsaPrivate) throws Exception {
        Cipher rsa = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
        rsa.init(Cipher.UNWRAP_MODE, rsaPrivate);
        Key aes = rsa.unwrap(wrappedKey, "AES", Cipher.SECRET_KEY);

        Cipher aesCipher = Cipher.getInstance("AES/GCM/NoPadding");
        aesCipher.init(Cipher.DECRYPT_MODE, (SecretKey)aes, new GCMParameterSpec(128, iv));
        return aesCipher.doFinal(ciphertext);
    }

    public static byte[] sign(byte[] data, Options.SignAlgo algo, KeyPair kp) throws Exception {
        if (algo == Options.SignAlgo.NONE) return new byte[0];
        Signature s = switch (algo) {
            case ED25519 -> Signature.getInstance("Ed25519");
            case ECDSA -> Signature.getInstance("SHA256withECDSA");
            case RSA -> Signature.getInstance("SHA256withRSA");
            default -> throw new IllegalArgumentException("Unsupported sign algo");
        };
        s.initSign(kp.getPrivate());
        s.update(data);
        return s.sign();
    }

    public static boolean verify(byte[] data, byte[] sig, Options.SignAlgo algo, PublicKey pub) throws Exception {
        if (algo == Options.SignAlgo.NONE) return true;
        Signature v = switch (algo) {
            case ED25519 -> Signature.getInstance("Ed25519");
            case ECDSA -> Signature.getInstance("SHA256withECDSA");
            case RSA -> Signature.getInstance("SHA256withRSA");
            default -> throw new IllegalArgumentException("Unsupported sign algo");
        };
        v.initVerify(pub);
        v.update(data);
        return v.verify(sig);
    }
}
