package com.example.kafkafs;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.nio.file.attribute.PosixFilePermission;
import java.time.Instant;
import java.util.Base64;
import java.util.Set;
import java.util.UUID;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Metadata {
    public String transferId;         // unique ID per file transfer (UUID by default)
    public String routingKey;         // for Kafka partitioning (hash/UUID/etc.)
    public String fileName;
    public long fileSize;
    public long totalChunks;
    public long chunkNumber;
    public String destinationPath;    // original path if not specified
    public long mtimeEpoch;
    public long atimeEpoch;
    public long ctimeEpoch;
    public Long birthtimeEpoch;       // nullable
    public String uid;
    public String gid;
    public String sid;
    public String user;
    public String group;
    public String posixPermissions;   // symbolic rwx or octal
    public String windowsPermissions; // DACL string if available
    public String acl;                // serialized ACL (if available)
    public byte[] xattr;              // arbitrary serialized XATTR
    public String selinuxContext;     // if available
    public String fileHashHex;        // overall file hash
    public String chunkHashHex;       // per-chunk hash
    public String optionsDescriptor;  // serialized Options for consumer
    public String publicKeyInfo;      // (encryption) base64-encoded SubjectPublicKeyInfo
    public String cipherInfo;         // e.g., AES-256-GCM
    public byte[] encryptedKey;       // RSA-OAEP wrapped AES key
    public byte[] signature;          // optional signature of file hash or manifest
    public boolean endOfFile;         // marker on final message

    public static String toJson(Metadata md) throws IOException {
        ObjectMapper m = new ObjectMapper();
        return m.writeValueAsString(md);
    }
    public static Metadata fromJson(String json) throws IOException {
        ObjectMapper m = new ObjectMapper();
        return m.readValue(json, Metadata.class);
    }

    public static String permsToSymbolic(Set<PosixFilePermission> perms) {
        String s = "";
        s += (perms.contains(PosixFilePermission.OWNER_READ) ? "r" : "-");
        s += (perms.contains(PosixFilePermission.OWNER_WRITE) ? "w" : "-");
        s += (perms.contains(PosixFilePermission.OWNER_EXECUTE) ? "x" : "-");
        s += (perms.contains(PosixFilePermission.GROUP_READ) ? "r" : "-");
        s += (perms.contains(PosixFilePermission.GROUP_WRITE) ? "w" : "-");
        s += (perms.contains(PosixFilePermission.GROUP_EXECUTE) ? "x" : "-");
        s += (perms.contains(PosixFilePermission.OTHERS_READ) ? "r" : "-");
        s += (perms.contains(PosixFilePermission.OTHERS_WRITE) ? "w" : "-");
        s += (perms.contains(PosixFilePermission.OTHERS_EXECUTE) ? "x" : "-");
        return s;
    }

    public static Metadata base(String fileName, long fileSize, long totalChunks, String destPath, Options opts){
        Metadata md = new Metadata();
        md.transferId = UUID.randomUUID().toString();
        md.routingKey = md.transferId; // default to UUID ensuring single partition
        md.fileName = fileName;
        md.fileSize = fileSize;
        md.totalChunks = totalChunks;
        md.destinationPath = destPath;
        md.optionsDescriptor = opts.toDescriptor();
        return md;
    }
}
