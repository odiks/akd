package com.example.kafkafs;

import java.time.Duration;

public class Options {
    public enum HashAlgo { SHA256, SHA384, SHA512 }
    public enum SignAlgo { RSA, ED25519, ECDSA, NONE }
    public enum Compression { LZ4, GZIP, NONE }
    public enum Encryption { AES256_GCM_RSA_OAEP, NONE }

    public HashAlgo hashAlgo = HashAlgo.SHA256;
    public SignAlgo signAlgo = SignAlgo.ED25519;
    public Compression compression = Compression.LZ4;
    public Encryption encryption = Encryption.NONE;
    public int chunkSizeBytes = 1 * 1024 * 1024;
    public Duration requestTimeout = Duration.ofSeconds(30);
    public Duration deliveryTimeout = Duration.ofSeconds(120);
    public Duration consumerPollTimeout = Duration.ofSeconds(2);
    public boolean requireAllChunks = true;
    public boolean retainTempFiles = false;
    public boolean preserveTimestamps = true;
    public boolean preservePermissions = true;
    public boolean preserveXAttrs = true;
    public boolean verifySignature = true;
    public boolean fsyncOnClose = true;
    public boolean enforceSingleBrokerRoute = true; // ensure a single partition via key

    // Extra options
    public boolean enableRateLimit = false;
    public long maxBytesPerSecond = 0L; // 0 = unlimited
    public int maxInFlightRequests = 5;
    public boolean idempotentProducer = true;
    public boolean enableAcksAll = true;
    public boolean enableSchemaValidation = false;

    // Serialize to a compact string for metadata
    public String toDescriptor() {
        return String.format(
            "hash=%s;sign=%s;comp=%s;enc=%s;chunk=%d;rt=%d;dt=%d;poll=%d;verifySig=%s;fsync=%s",
            hashAlgo, signAlgo, compression, encryption, chunkSizeBytes,
            requestTimeout.toMillis(), deliveryTimeout.toMillis(),
            consumerPollTimeout.toMillis(), verifySignature, fsyncOnClose
        );
    }

    public static Options defaults() { return new Options(); }
}
