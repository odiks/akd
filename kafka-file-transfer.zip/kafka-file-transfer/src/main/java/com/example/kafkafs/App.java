package com.example.kafkafs;

public class App {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.err.println("Usage: java -jar kafka-file-transfer.jar [producer|consumer] ...");
            System.exit(ErrorCode.VALIDATION_ERROR.code());
        }
        String cmd = args[0].toLowerCase();
        String[] subArgs = new String[Math.max(0, args.length - 1)];
        if (args.length > 1) {
            System.arraycopy(args, 1, subArgs, 0, args.length - 1);
        }
        try {
            switch (cmd) {
                case "producer" -> ProducerCLI.main(subArgs);
                case "consumer" -> ConsumerCLI.main(subArgs);
                default -> {
                    System.err.println("Unknown command: " + cmd);
                    System.exit(ErrorCode.VALIDATION_ERROR.code());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(ErrorCode.UNKNOWN.code());
        }
    }
}
