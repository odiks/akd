package com.example.kafkafs;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class HashUtil {
    public static byte[] digest(byte[] data, Options.HashAlgo algo){
        String name = switch (algo){
            case SHA256 -> "SHA-256";
            case SHA384 -> "SHA-384";
            case SHA512 -> "SHA-512";
        };
        try {
            MessageDigest md = MessageDigest.getInstance(name);
            return md.digest(data);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
    public static String toHex(byte[] bytes){
        StringBuilder sb = new StringBuilder(bytes.length*2);
        for (byte b: bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
