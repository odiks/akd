package com.example.kafkafs;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.BinaryEncoder;
import org.apache.avro.io.DatumWriter;
import org.apache.avro.io.EncoderFactory;
import org.apache.avro.generic.GenericDatumWriter;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class ManifestAvro {
    private static final Schema SCHEMA;
    static {
        try (InputStream in = ManifestAvro.class.getResourceAsStream("/file-manifest.avsc")) {
            String s = new String(in.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
            SCHEMA = new Schema.Parser().parse(s);
        } catch (IOException e){
            throw new RuntimeException("Schema load failed", e);
        }
    }

    public static byte[] serialize(String transferId, String routingKey, Metadata base, List<String> chunkHashes) throws IOException {
        GenericRecord rec = new GenericData.Record(SCHEMA);
        rec.put("transferId", transferId);
        rec.put("routingKey", routingKey);
        rec.put("fileName", base.fileName);
        rec.put("fileSize", base.fileSize);
        rec.put("totalChunks", base.totalChunks);
        rec.put("destinationPath", base.destinationPath);
        rec.put("fileHashHex", base.fileHashHex);
        rec.put("optionsDescriptor", base.optionsDescriptor);
        org.apache.avro.generic.GenericData.Array<String> arr =
            new org.apache.avro.generic.GenericData.Array<>(chunkHashes.size(), SCHEMA.getField("chunkHashes").schema());
        for (String h: chunkHashes) arr.add(h);
        rec.put("chunkHashes", arr);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        BinaryEncoder enc = EncoderFactory.get().binaryEncoder(baos, null);
        DatumWriter<GenericRecord> writer = new GenericDatumWriter<>(SCHEMA);
        writer.write(rec, enc);
        enc.flush();
        return baos.toByteArray();
    }
}
