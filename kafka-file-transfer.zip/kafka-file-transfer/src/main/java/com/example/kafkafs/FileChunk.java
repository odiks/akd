package com.example.kafkafs;

public class FileChunk {
    public String metadataJson;
    public byte[] payload; // possibly compressed/encrypted

    public FileChunk(){}
    public FileChunk(String metadataJson, byte[] payload){
        this.metadataJson = metadataJson;
        this.payload = payload;
    }
}
