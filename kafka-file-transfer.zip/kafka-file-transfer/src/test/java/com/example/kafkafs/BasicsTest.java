package com.example.kafkafs;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.util.Random;

public class BasicsTest {

    @Test
    void testHashRoundtrip(){
        byte[] data = "hello".getBytes();
        String h = HashUtil.toHex(HashUtil.digest(data, Options.HashAlgo.SHA256));
        assertEquals(64, h.length());
    }

    @Test
    void testCompressionRoundtrip() throws Exception {
        byte[] data = new byte[1024*64];
        new Random().nextBytes(data);
        for (Options.Compression c: Options.Compression.values()){
            byte[] comp = CompressionUtil.compress(data, c);
            byte[] dec = CompressionUtil.decompress(comp, c);
            assertArrayEquals(data, dec);
        }
    }

    @Test
    void testCryptoRoundtrip() throws Exception {
        byte[] data = "secret-data".getBytes();
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        kpg.initialize(3072);
        KeyPair kp = kpg.generateKeyPair();
        var enc = CryptoUtil.encryptAesGcmRsaOaep(data, kp.getPublic());
        byte[] dec = CryptoUtil.decryptAesGcmRsaOaep(enc.iv(), enc.ciphertext(), enc.wrappedKey(), kp.getPrivate());
        assertArrayEquals(data, dec);
    }

    @Test
    void testSignatureEd25519() throws Exception {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("Ed25519");
        KeyPair kp = kpg.generateKeyPair();
        byte[] data = "abc".getBytes();
        byte[] sig = CryptoUtil.sign(data, Options.SignAlgo.ED25519, kp);
        boolean ok = CryptoUtil.verify(data, sig, Options.SignAlgo.ED25519, kp.getPublic());
        assertTrue(ok);
    }
}
