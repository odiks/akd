# Kafka File Transfer (Producer & Consumer)

Java 17 + Kafka clients to transfer files in **chunks** with full metadata, optional **encryption**, **compression**, integrity checks, and controlled routing to a single broker/partition.

## Features (per your spec)

- Transfers all file metadata (name, size, times, owner/group, POSIX permissions, ACL/XATTR/SELinux when available).
- Optional encryption: AES-256-GCM with RSA-OAEP-wrapped key.
- Optional compression: LZ4 (default) or GZIP.
- Supports any file type and size (chunked), configurable chunk size (default 1 MiB).
- Integrity control: per-chunk hash + whole-file hash (SHA-256/384/512).
- Metadata options embedded so the consumer knows how to reconstruct (hash/compression/encryption/chunk size).
- Reception control: bitset tracking of all chunks; EOF marker; verification of missing chunks.
- Unique routing key (UUID) so the file is confined to one Kafka partition/broker.
- Exit codes for bash `$?` (see **Error codes**).

## Additional options proposed

- `--rate-limit` via `maxBytesPerSecond` (hook point in code; left disabled by default).
- `--idempotent-producer` on by default; `acks=all` to improve durability.
- `--fsync-on-close` to be extra safe when writing the reconstructed file.
- `--retain-temp-files` for debugging partial assemblies.
- `--preserve-timestamps/permissions/xattrs` best-effort.
- `--max-in-flight` producer safety dial.
- Timeout knobs for request/delivery/poll.
- (Future) schema validation toggle for metadata JSON.

## Build

```bash
cd kafka-file-transfer
mvn -q -DskipTests package
```

Resulting JAR: `target/kafka-file-transfer-1.0.0-shaded.jar`

## Usage

### Producer
```bash
java -jar target/kafka-file-transfer-1.0.0-shaded.jar producer   --bootstrap "broker1:9092,broker2:9092"   --topic file-transfer   --file /path/to/src.bin   --dest /restore/dir/src.bin   --hash SHA256 --sign ED25519 --comp LZ4 --enc NONE --chunk 1048576
```

**Encryption** (requires RSA public key, Base64 X.509 DER):

```bash
java -jar ... producer ... --enc AES256_GCM_RSA_OAEP --pubkey "$(cat rsa_pub.der.b64)"
```

### Consumer
```bash
java -jar target/kafka-file-transfer-1.0.0-shaded.jar consumer   --bootstrap "broker1:9092,broker2:9092"   --group file-transfer-consumers   --topic file-transfer   --outdir /restore/dir
```

If producer used encryption, provide RSA private key (Base64 PKCS#8 DER):

```bash
java -jar ... consumer ... --privkey "$(cat rsa_priv_pkcs8.der.b64)"
```

If producer used signing, provide the public key for verification:

```bash
java -jar ... consumer ... --signpub "$(cat ed25519_pub.der.b64)"
```

## Error codes

- `0` OK
- `10` CONFIG_ERROR
- `20` IO_ERROR
- `30` KAFKA_ERROR
- `40` CRYPTO_ERROR
- `50` INTEGRITY_FAILED
- `60` TIMEOUT
- `70` INTERRUPTED
- `80` VALIDATION_ERROR
- `90` UNKNOWN

These are mapped in `ErrorCode.java` and returned via `System.exit(code)` so `$?` in bash is set.

## Rocky Linux 9 (systemd, clustered Kafka)

- Ensure Kafka brokers run under systemd (e.g. `kafka.service` or `kafka@1.service`).
- Create topic (replication 3, partitions 12 recommended):

```bash
/usr/bin/kafka-topics --bootstrap-server broker1:9092 --create   --topic file-transfer --replication-factor 3 --partitions 12   --config min.insync.replicas=2 --config cleanup.policy=delete
```

- Check topic:
```bash
/usr/bin/kafka-topics --bootstrap-server broker1:9092 --describe --topic file-transfer
```

### Integration test script (non-Docker)

See `scripts/integration-test-rocky9.sh`. It will:
- Create topic if missing
- Send a test file and reconstruct it
- Compare sha256 sums
- Return exit code accordingly

## Notes / limitations

- ACL and XATTR collection is best-effort and platform dependent.
- `ctime` is not exposed by Java NIO; we approximate with lastModified.
- Exactly-once delivery is not implemented; idempotent producer + acks=all used instead.
- Signature generation in the sample uses an ephemeral keypair. Replace with your key management as needed.


## Nouveautés (v1.1)
- **Transactions Kafka** optionnelles (`--tx true`) : envoi atomique des chunks + EOF + **manifest**.
- **Manifest Avro** sur `<topic>-manifest` : contient la liste des hashes de chunks et les options appliquées.
- **Isolation `read_committed`** côté consumer pour ignorer les transactions avortées.
- **Reprise** en cas d’interruption : checkpoint local `.ckpt` par `transferId` ; les chunks déjà reçus ne sont pas reperdus.

### Exemple (transactions + manifest)
```bash
java -jar target/kafka-file-transfer-1.0.0-shaded.jar producer   --bootstrap "broker1:9092" --topic file-transfer --file /path/src.bin   --tx true --manifest-topic file-transfer-manifest
```
