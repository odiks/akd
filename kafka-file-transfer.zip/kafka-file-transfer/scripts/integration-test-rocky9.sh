#!/usr/bin/env bash
set -euo pipefail

TOPIC="${TOPIC:-file-transfer}"
BOOTSTRAP="${BOOTSTRAP:-localhost:9092}"
GROUP_ID="${GROUP_ID:-kft-test}"
OUTDIR="${OUTDIR:-/tmp/kft-out}"
JAR="${JAR:-target/kafka-file-transfer-1.0.0-shaded.jar}"

# Ensure topic exists
if ! /usr/bin/kafka-topics --bootstrap-server "$BOOTSTRAP" --list | grep -q "^${TOPIC}$"; then
  /usr/bin/kafka-topics --bootstrap-server "$BOOTSTRAP" --create --topic "$TOPIC" --partitions 12 --replication-factor 1
fi

TEST_FILE="${1:-/etc/hosts}"
mkdir -p "$OUTDIR"

# Produce
java -jar "$JAR" producer --bootstrap "$BOOTSTRAP" --topic "$TOPIC" --file "$TEST_FILE" --dest "$OUTDIR/$(basename "$TEST_FILE")"
P_RC=$?

# Consume one file and exit (use a dedicated invocation)
timeout 20s java -jar "$JAR" consumer --bootstrap "$BOOTSTRAP" --group "$GROUP_ID" --topic "$TOPIC" --outdir "$OUTDIR" || true
C_RC=$?

if [[ $P_RC -ne 0 || $C_RC -ne 0 ]]; then
  echo "Producer or consumer returned non-zero: P=$P_RC C=$C_RC" >&2
  exit 1
fi

sha1=$(sha256sum "$TEST_FILE" | awk '{print $1}')
sha2=$(sha256sum "$OUTDIR/$(basename "$TEST_FILE")" | awk '{print $1}')
if [[ "$sha1" != "$sha2" ]]; then
  echo "Hash mismatch!" >&2
  exit 2
fi

echo "Integration test OK"
exit 0
