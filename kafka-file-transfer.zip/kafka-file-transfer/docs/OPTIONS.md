# Options reference embedded in metadata

- `hash=SHA256|SHA384|SHA512`
- `sign=RSA|ED25519|ECDSA|NONE`
- `comp=LZ4|GZIP|NONE`
- `enc=AES256_GCM_RSA_OAEP|NONE`
- `chunk=<bytes>`
- `rt=<request-timeout-ms>`
- `dt=<delivery-timeout-ms>`
- `poll=<consumer-poll-timeout-ms>`
- `verifySig=true|false`
- `fsync=true|false`

The consumer parses `optionsDescriptor` from `Metadata` so it can apply the same algorithms automatically.
