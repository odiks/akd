package com.example.kafka.filetransfer.cli;

import com.example.kafka.filetransfer.ErrorCode;
import com.example.kafka.filetransfer.model.TransferConfig;
import com.example.kafka.filetransfer.producer.FileTransferProducer;
import org.apache.kafka.common.KafkaException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;
import picocli.CommandLine.Parameters;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.util.Properties;
import java.util.concurrent.Callable;

@Command(name = "producer",
         mixinStandardHelpOptions = true,
         description = "Lit un fichier, le découpe en chunks, et l'envoie vers un topic Kafka.")
public class ProducerCommand implements Callable<Integer> {

    private static final Logger logger = LoggerFactory.getLogger(ProducerCommand.class);

    @Parameters(index = "0", description = "Le chemin complet du fichier à envoyer.")
    private File file;

    @Option(names = {"-c", "--config"}, required = true, description = "Chemin vers le fichier de propriétés du producteur.")
    private File configFile;

    @Override
    public Integer call() {
        try {
            MDC.put("hostname", InetAddress.getLocalHost().getHostName());
        } catch (UnknownHostException e) {
            MDC.put("hostname", "unknown");
        }
        MDC.put("appName", "producer-cli");

        try {
            // 1. Validation initiale des arguments
            if (!Files.exists(file.toPath())) {
                logger.error("Erreur de validation : Le fichier '{}' n'existe pas.", file.getAbsolutePath());
                return ErrorCode.VALIDATION_ERROR.getCode();
            }
            if (!Files.isReadable(file.toPath())) {
                logger.error("Erreur d'IO : Le fichier '{}' n'est pas lisible.", file.getAbsolutePath());
                return ErrorCode.IO_ERROR.getCode();
            }

            // 2. Chargement de la configuration
            Properties props = new Properties();
            try (FileInputStream fis = new FileInputStream(configFile)) {
                props.load(fis);
            } catch (FileNotFoundException e) {
                logger.error("Erreur de configuration : Le fichier de propriétés '{}' est introuvable.", configFile.getAbsolutePath());
                return ErrorCode.CONFIG_ERROR.getCode();
            } catch (IOException e) {
                logger.error("Erreur d'IO : Impossible de lire le fichier de propriétés '{}'.", configFile.getAbsolutePath(), e);
                return ErrorCode.IO_ERROR.getCode();
            }

            // 3. Exécution du processus métier
            // CORRECTION: On passe le mode PRODUCER pour la validation
            TransferConfig transferConfig = new TransferConfig(props, TransferConfig.AppMode.PRODUCER);
            FileTransferProducer producer = new FileTransferProducer(transferConfig);

            logger.info("Démarrage du transfert pour le fichier : {}", file.getAbsolutePath());
            producer.startTransfer(file.toPath());

            logger.info("Transfert du fichier initié et terminé avec succès côté producteur. [exitCode={}]", ErrorCode.OK.getCode());
            return ErrorCode.OK.getCode();

        } catch (IllegalArgumentException e) {
            logger.error("Erreur de configuration : {}.", e.getMessage());
            return ErrorCode.CONFIG_ERROR.getCode();
        } catch (KafkaException e) {
            logger.error("Erreur Kafka : {}. Vérifiez la connexion aux brokers.", e.getMessage());
            return ErrorCode.KAFKA_ERROR.getCode();
        } catch (Exception e) {
            logger.error("Erreur Inconnue : {}.", e.getMessage(), e);
            return ErrorCode.UNKNOWN.getCode();
        } finally {
            MDC.clear();
        }
    }
}