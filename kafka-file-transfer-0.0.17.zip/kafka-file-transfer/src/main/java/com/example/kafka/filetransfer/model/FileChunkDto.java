package com.example.kafka.filetransfer.model;

import java.util.List;

/**
 * DTO (Data Transfer Object) représentant un chunk de fichier pour la sérialisation JSON.
 * C'est la version "lisible" du message Protobuf.
 */
public class FileChunkDto {

    // --- Métadonnées de Transfert ---
    public String transferId;
    public String fileName;
    public long fileSize;
    public int totalChunks;
    public int chunkNumber;
    public int originalChunkSize;

    // --- Métadonnées de Provenance (CHAMPS CORRIGÉS) ---
    public String sourceHostname;
    public String sourceUsername;

    // --- Métadonnées d'Intégrité ---
    public String hashAlgorithm;
    public String fileHash;
    public String chunkHash;
    
    // --- Métadonnées de Compression (CHAMPS CORRIGÉS) ---
    public String compressionAlgorithm;
    public String compressedFileHash;

    // --- Données (encodées en Base64) ---
    public String data;

    // --- Métadonnées de Reconstruction ---
    public String destinationPath;
    public long mtimeEpoch;
    public long atimeEpoch;
    public Long birthtimeEpoch;

    // --- Permissions ---
    public String posixPermissions;
    public String ownerName;
    public String groupName;
    public List<AclEntryDto> windowsAcls;

    // --- Options de Transfert ---
    public boolean isFinalChunk;

    // --- Sécurité ---
    public String encryptionCipher;
    public String encryptedSymmetricKey;

    public static class AclEntryDto {
        public String type;
        public String principal;
        public List<String> permissions;
        public List<String> flags;
    }
}