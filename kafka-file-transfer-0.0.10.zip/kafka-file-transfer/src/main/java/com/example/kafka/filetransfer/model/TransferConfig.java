package com.example.kafka.filetransfer.model;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.ByteArrayDeserializer;
import org.apache.kafka.common.serialization.ByteArraySerializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.Properties;

public class TransferConfig {

    private final Properties props;

    /**
     * NOUVEAU: Énumération pour un choix de format de sérialisation sécurisé.
     */
    public enum SerializationFormat {
        PROTOBUF,
        JSON
    }

    public TransferConfig(Properties props) {
        this.props = props;
        validateRequired();
    }

    private void validateRequired() {
        if (props.getProperty("bootstrap.servers") == null) {
            throw new IllegalArgumentException("La propriété 'bootstrap.servers' est requise.");
        }
        if (props.getProperty("topic.data") == null) {
            throw new IllegalArgumentException("La propriété 'topic.data' est requise.");
        }
    }

    // --- Getters de configuration générale ---
    public String getDataTopic() { return props.getProperty("topic.data"); }
    public int getChunkSize() { return Integer.parseInt(props.getProperty("chunk.size", "1048576")); }
    public String getHashAlgorithm() { return props.getProperty("hash.algorithm", "SHA-256"); }
    public String getCompressionAlgorithm() { return props.getProperty("compression.algorithm", "NONE"); }
    public String getStagingDirectory() { return props.getProperty("staging.directory", "/tmp/kafka-staging"); }
    public long getTransferTimeoutHours() { return Long.parseLong(props.getProperty("transfer.timeout.hours", "24")); }

    /**
     * NOUVEAU: Retourne le format de sérialisation configuré.
     * @return Le format de sérialisation (PROTOBUF par défaut).
     */
    public SerializationFormat getSerializationFormat() {
        String format = props.getProperty("serialization.format", "PROTOBUF").toUpperCase();
        try {
            return SerializationFormat.valueOf(format);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Format de sérialisation invalide : '" + format + "'. Les valeurs possibles sont PROTOBUF, JSON.");
        }
    }


    // --- Getters de configuration de sécurité ---
    public boolean isEncryptionEnabled() { return Boolean.parseBoolean(props.getProperty("encryption.enabled", "false")); }
    public String getConsumerPublicKeyPath() { return props.getProperty("encryption.consumer.public_key.path"); }
    public String getConsumerPrivateKeyPath() { return props.getProperty("encryption.private_key.path"); }

    // --- Getters de configuration de métadonnées (côté consumer) ---
    public boolean shouldRestorePermissions() { return Boolean.parseBoolean(props.getProperty("metadata.restore.permissions", "true")); }
    public boolean shouldRestoreOwner() { return Boolean.parseBoolean(props.getProperty("metadata.restore.owner", "false")); }
    public boolean shouldRestoreTimestamps() { return Boolean.parseBoolean(props.getProperty("metadata.restore.timestamps", "true")); }

    public Properties getKafkaProducerProperties() {
        Properties kafkaProps = new Properties();
        kafkaProps.putAll(this.props);
        kafkaProps.putIfAbsent(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, "true");
        kafkaProps.putIfAbsent(ProducerConfig.ACKS_CONFIG, "all");
        kafkaProps.putIfAbsent(ProducerConfig.RETRIES_CONFIG, "5");
        kafkaProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        kafkaProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, ByteArraySerializer.class.getName());
        return kafkaProps;
    }

    public Properties getKafkaConsumerProperties() {
        Properties kafkaProps = new Properties();
        kafkaProps.putAll(this.props);
        if (kafkaProps.getProperty(ConsumerConfig.GROUP_ID_CONFIG) == null) {
            throw new IllegalArgumentException("La propriété 'group.id' est requise pour le consommateur.");
        }
        kafkaProps.putIfAbsent(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        kafkaProps.putIfAbsent(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        kafkaProps.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        kafkaProps.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, ByteArrayDeserializer.class.getName());
        return kafkaProps;
    }
}