# Application de Transfert de Fichiers via Kafka

Cette application fournit une solution robuste et performante pour transférer des fichiers de manière sécurisée et fiable en utilisant Apache Kafka comme bus de messagerie.

## Fonctionnalités

-   **Découpage en Chunks :** Support des fichiers de toutes tailles.
-   **Transfert des Métadonnées :** Conserve les permissions, les dates et les propriétaires (configurable).
-   **Vérification d'Intégrité :** Utilise des hashs (SHA-256/384/512) pour garantir qu'aucun bit n'est corrompu.
-   **Compression Optionnelle :** Réduit l'utilisation de la bande passante avec Gzip ou LZ4.
-   **Chiffrement de Bout-en-Bout Optionnel :** Sécurise les données en transit avec un chiffrement hybride RSA/AES.
-   **Monitoring :** Utilise un topic de statut dédié pour suivre la progression des transferts.
-   **Interface en Ligne de Commande :** Facile à utiliser et à scripter grâce à Picocli.

## Prérequis

-   Java Development Kit (JDK) 11 ou supérieur
-   Apache Maven 3.6 ou supérieur
-   Un cluster Apache Kafka accessible
-   `openssl` pour la génération des clés de chiffrement

## Compilation

Pour compiler le projet et créer un JAR exécutable unique (uber-jar), exécutez la commande suivante à la racine du projet :

```bash
mvn clean package
```
Le JAR se trouvera dans le répertoire `target/kafka-file-transfer-1.0.0.jar`.

## Configuration

L'application est pilotée par des fichiers de configuration externes.

1.  Créez un répertoire `config/` à côté du JAR.
2.  Copiez les fichiers `*.properties.template` du répertoire `src/main/resources` dans `config/` et renommez-les en `*.properties`.
3.  Éditez ces fichiers pour correspondre à votre environnement Kafka.

### Génération des Clés (pour le Chiffrement)

Si vous souhaitez utiliser le chiffrement, vous devez générer une paire de clés RSA pour le consommateur.

1.  Créez un répertoire `security/` à côté du JAR.
2.  Exécutez les commandes suivantes :

    ```bash
    # Générer la clé privée (garder ce fichier secret !)
    openssl genpkey -algorithm RSA -out security/consumer_private.p8 -pkeyopt rsa_keygen_bits:2048

    # Extraire la clé publique depuis la clé privée
    openssl rsa -in security/consumer_private.p8 -pubout -out security/consumer_public.pem
    ```
3.  Assurez-vous que les chemins vers ces fichiers sont corrects dans vos fichiers de configuration.

## Exécution

### Lancer le Consommateur

Ouvrez un terminal et lancez le consommateur. Il se mettra en attente de fichiers.

```bash
java -jar target/kafka-file-transfer-1.0.0.jar consumer \
  --config config/consumer.properties \
  --destination-dir /chemin/vers/votre/repertoire/de/sortie
```

### Lancer le Producteur

Ouvrez un second terminal pour envoyer un fichier.

```bash
java -jar target/kafka-file-transfer-1.0.0.jar producer \
  /chemin/vers/votre/fichier/a/envoyer.zip \
  --config config/producer.properties
```