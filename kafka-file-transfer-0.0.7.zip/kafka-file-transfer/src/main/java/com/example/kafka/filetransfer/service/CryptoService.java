package com.example.kafka.filetransfer.service;

import com.example.kafka.filetransfer.model.TransferConfig;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

/**
 * Service gérant toutes les opérations cryptographiques.
 * Implémente un chiffrement hybride RSA/AES.
 */
public class CryptoService {

    private static final String RSA_TRANSFORMATION = "RSA/ECB/OAEPWithSHA-256AndMGF1Padding";
    private static final String AES_TRANSFORMATION = "AES/GCM/NoPadding";
    private static final String AES_ALGORITHM = "AES";

    private static final int GCM_IV_LENGTH = 12;
    private static final int GCM_TAG_LENGTH = 128;

    private final TransferConfig config;
    private final PrivateKey consumerPrivateKey;

    public CryptoService(TransferConfig config) {
        this.config = config;
        if (config.getConsumerPrivateKeyPath() != null) {
            try {
                this.consumerPrivateKey = loadPrivateKey(config.getConsumerPrivateKeyPath());
            } catch (Exception e) {
                throw new IllegalArgumentException("Impossible de charger la clé privée depuis " + config.getConsumerPrivateKeyPath(), e);
            }
        } else {
            this.consumerPrivateKey = null;
        }
    }

    public EncryptionResult prepareEncryption() throws GeneralSecurityException, IOException {
        if (!config.isEncryptionEnabled()) {
            return EncryptionResult.unencrypted();
        }

        KeyGenerator keyGen = KeyGenerator.getInstance(AES_ALGORITHM);
        keyGen.init(256);
        SecretKey aesKey = keyGen.generateKey();

        PublicKey rsaPublicKey = loadPublicKey(config.getConsumerPublicKeyPath());

        Cipher rsaCipher = Cipher.getInstance(RSA_TRANSFORMATION);
        rsaCipher.init(Cipher.ENCRYPT_MODE, rsaPublicKey);
        byte[] encryptedAesKey = rsaCipher.doFinal(aesKey.getEncoded());

        return EncryptionResult.encrypted(aesKey, encryptedAesKey, AES_TRANSFORMATION);
    }

    public byte[] encrypt(byte[] data, EncryptionResult result) throws GeneralSecurityException {
        if (!result.isEncrypted()) {
            return data;
        }

        byte[] iv = new byte[GCM_IV_LENGTH];
        new SecureRandom().nextBytes(iv);

        Cipher aesCipher = Cipher.getInstance(result.getCipherName());
        GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
        aesCipher.init(Cipher.ENCRYPT_MODE, result.getSymmetricKey(), gcmParameterSpec);

        byte[] encryptedData = aesCipher.doFinal(data);

        ByteBuffer byteBuffer = ByteBuffer.allocate(iv.length + encryptedData.length);
        byteBuffer.put(iv);
        byteBuffer.put(encryptedData);
        return byteBuffer.array();
    }

    public byte[] decrypt(byte[] dataWithIv, byte[] encryptedSymmetricKey, String cipherName) throws GeneralSecurityException {
        if (consumerPrivateKey == null) {
            throw new GeneralSecurityException("Clé privée du consommateur non disponible pour le déchiffrement.");
        }

        Cipher rsaCipher = Cipher.getInstance(RSA_TRANSFORMATION);
        rsaCipher.init(Cipher.DECRYPT_MODE, consumerPrivateKey);
        byte[] decryptedAesKeyBytes = rsaCipher.doFinal(encryptedSymmetricKey);
        SecretKey aesKey = new SecretKeySpec(decryptedAesKeyBytes, 0, decryptedAesKeyBytes.length, AES_ALGORITHM);

        if (dataWithIv.length < GCM_IV_LENGTH) {
            throw new GeneralSecurityException("Données chiffrées invalides : taille insuffisante pour contenir un IV.");
        }
        ByteBuffer byteBuffer = ByteBuffer.wrap(dataWithIv);
        byte[] iv = new byte[GCM_IV_LENGTH];
        byteBuffer.get(iv);
        byte[] encryptedData = new byte[byteBuffer.remaining()];
        byteBuffer.get(encryptedData);

        Cipher aesCipher = Cipher.getInstance(cipherName);
        GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
        aesCipher.init(Cipher.DECRYPT_MODE, aesKey, gcmParameterSpec);
        return aesCipher.doFinal(encryptedData);
    }

    private PublicKey loadPublicKey(String path) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
        String keyString = new String(Files.readAllBytes(Paths.get(path)))
                .replace("-----BEGIN PUBLIC KEY-----", "")
                .replaceAll("\\R", "")
                .replace("-----END PUBLIC KEY-----", "");
        byte[] decoded = Base64.getDecoder().decode(keyString);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return keyFactory.generatePublic(new X509EncodedKeySpec(decoded));
    }

    private PrivateKey loadPrivateKey(String path) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
        String keyString = new String(Files.readAllBytes(Paths.get(path)))
                .replace("-----BEGIN PRIVATE KEY-----", "")
                .replaceAll("\\R", "")
                .replace("-----END PRIVATE KEY-----", "");
        byte[] decoded = Base64.getDecoder().decode(keyString);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return keyFactory.generatePrivate(new PKCS8EncodedKeySpec(decoded));
    }

    /**
     * Classe interne pour encapsuler le résultat de la préparation du chiffrement.
     */
    public static class EncryptionResult {
        private final boolean encrypted;
        private final SecretKey symmetricKey;
        private final byte[] encryptedSymmetricKey;
        private final String cipherName;

        // CORRECTION: Le constructeur est correct ici, l'erreur venait de la logique d'appel
        private EncryptionResult(boolean encrypted, SecretKey key, byte[] encryptedKey, String cipher) {
            this.encrypted = encrypted;
            this.symmetricKey = key;
            this.encryptedSymmetricKey = encryptedKey;
            this.cipherName = cipher;
        }

        public static EncryptionResult unencrypted() {
            return new EncryptionResult(false, null, null, null);
        }

        public static EncryptionResult encrypted(SecretKey key, byte[] encryptedKey, String cipher) {
            return new EncryptionResult(true, key, encryptedKey, cipher);
        }

        public boolean isEncrypted() { return encrypted; }
        public SecretKey getSymmetricKey() { return symmetricKey; }
        public byte[] getEncryptedSymmetricKey() { return encryptedSymmetricKey; }
        public String getCipherName() { return cipherName; }
    }
}