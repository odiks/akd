package com.example.kafka.filetransfer.service;

import com.example.kafka.filetransfer.proto.HashAlgorithm;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Objects;

/**
 * Service responsable de toutes les opérations de hachage cryptographique.
 */
public class HashingService {

    /**
     * Calcule le hash d'un fichier entier en le lisant de manière streamée.
     * @param filePath Le chemin vers le fichier.
     * @param algorithm L'algorithme à utiliser (ex: "SHA-256").
     * @return Le hash sous forme de chaîne hexadécimale.
     * @throws IOException si une erreur de lecture se produit.
     * @throws NoSuchAlgorithmException si l'algorithme n'est pas supporté.
     */
    public String calculateFileHash(Path filePath, String algorithm) throws IOException, NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance(algorithm.replace("_", "-"));
        try (InputStream fis = Files.newInputStream(filePath)) {
            byte[] byteArray = new byte[8192];
            int bytesCount;
            while ((bytesCount = fis.read(byteArray)) != -1) {
                digest.update(byteArray, 0, bytesCount);
            }
        }
        return bytesToHex(digest.digest());
    }

    /**
     * Calcule le hash d'un chunk de données (tableau d'octets).
     * @param data Le chunk de données.
     * @param algorithm L'algorithme à utiliser.
     * @return Le hash sous forme de chaîne hexadécimale.
     * @throws NoSuchAlgorithmException si l'algorithme n'est pas supporté.
     */
    public String calculateChunkHash(byte[] data, String algorithm) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance(algorithm.replace("_", "-"));
        return bytesToHex(digest.digest(data));
    }

    /**
     * Vérifie l'intégrité d'un fichier en comparant son hash calculé avec un hash attendu.
     * @param filePath Le chemin vers le fichier à vérifier.
     * @param expectedHash Le hash attendu.
     * @param algorithm L'algorithme à utiliser pour le calcul.
     * @throws SecurityException si les hashs ne correspondent pas.
     */
    public void verifyFileIntegrity(Path filePath, String expectedHash, HashAlgorithm algorithm) throws IOException, NoSuchAlgorithmException {
        String actualHash = calculateFileHash(filePath, algorithm.name());
        if (!Objects.equals(expectedHash, actualHash)) {
            throw new SecurityException(String.format("Échec de la vérification d'intégrité ! Hash attendu : %s, Hash calculé : %s",
                    expectedHash, actualHash));
        }
    }

    /**
     * Utilitaire pour convertir un tableau d'octets en chaîne hexadécimale.
     */
    private String bytesToHex(byte[] hash) {
        StringBuilder hexString = new StringBuilder(2 * hash.length);
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }
}