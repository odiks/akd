package com.example.kafka.filetransfer.service;

import com.example.kafka.filetransfer.model.TransferConfig;
import com.example.kafka.filetransfer.proto.AclEntry;
import com.example.kafka.filetransfer.proto.CompressionAlgorithm;
import com.example.kafka.filetransfer.proto.FileChunkMessage;
import com.google.protobuf.Int64Value;
import com.google.protobuf.StringValue;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.*;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Service responsable de la gestion des métadonnées (le "manifeste") du fichier,
 * incluant la prise en charge des permissions POSIX et Windows (ACLs).
 */
public class ManifestService {
    // ... Le début de la classe (constructeurs, createManifest, applyMetadata, etc.) est identique ...
    private final TransferConfig config;
    public ManifestService() { this.config = null; }
    public ManifestService(TransferConfig config) { this.config = config; }
    public FileChunkMessage.Builder createManifest(Path filePath, String transferId) throws IOException {
        FileChunkMessage.Builder builder = FileChunkMessage.newBuilder();
        builder.setTransferId(transferId);
        builder.setFileName(filePath.getFileName().toString());
        BasicFileAttributes basicAttrs = Files.readAttributes(filePath, BasicFileAttributes.class);
        builder.setFileSize(basicAttrs.size());
        builder.setMtimeEpoch(basicAttrs.lastModifiedTime().toMillis());
        builder.setAtimeEpoch(basicAttrs.lastAccessTime().toMillis());
        if (basicAttrs.creationTime() != null) {
            builder.setBirthtimeEpoch(Int64Value.of(basicAttrs.creationTime().toMillis()));
        }
        if (FileSystems.getDefault().supportedFileAttributeViews().contains("posix")) {
            PosixFileAttributes posixAttrs = Files.readAttributes(filePath, PosixFileAttributes.class);
            builder.setOwnerName(StringValue.of(posixAttrs.owner().getName()));
            builder.setGroupName(StringValue.of(posixAttrs.group().getName()));
            builder.setPosixPermissions(StringValue.of(PosixFilePermissions.toString(posixAttrs.permissions())));
        }
        AclFileAttributeView aclView = Files.getFileAttributeView(filePath, AclFileAttributeView.class);
        if (aclView != null) {
            for (java.nio.file.attribute.AclEntry entry : aclView.getAcl()) {
                AclEntry.Builder protoAclEntry = AclEntry.newBuilder()
                        .setType(entry.type().name())
                        .setPrincipal(entry.principal().getName());
                for (AclEntryPermission perm : entry.permissions()) {
                    protoAclEntry.addPermissions(perm.name());
                }
                for (AclEntryFlag flag : entry.flags()) {
                    protoAclEntry.addFlags(flag.name());
                }
                builder.addWindowsAcls(protoAclEntry.build());
            }
        }
        return builder;
    }
    public void applyMetadata(Path filePath, FileChunkMessage metadata) throws IOException {
        if (config == null) throw new IllegalStateException("Le service doit être initialisé avec une configuration pour appliquer les métadonnées.");
        if (config.shouldRestoreTimestamps()) {
            Files.setLastModifiedTime(filePath, FileTime.fromMillis(metadata.getMtimeEpoch()));
        }
        AclFileAttributeView aclView = Files.getFileAttributeView(filePath, AclFileAttributeView.class);
        if (!metadata.getWindowsAclsList().isEmpty() && aclView != null) {
            applyWindowsAcls(filePath, metadata, aclView);
        } else if (FileSystems.getDefault().supportedFileAttributeViews().contains("posix")) {
            applyPosixPermissions(filePath, metadata);
        }
    }
    private void applyPosixPermissions(Path filePath, FileChunkMessage metadata) throws IOException {
        if (config.shouldRestorePermissions() && metadata.hasPosixPermissions()) {
            Files.setPosixFilePermissions(filePath, PosixFilePermissions.fromString(metadata.getPosixPermissions().getValue()));
        }
        if (config.shouldRestoreOwner() && metadata.hasOwnerName() && metadata.hasGroupName()) {
            try {
                UserPrincipalLookupService lookupService = FileSystems.getDefault().getUserPrincipalLookupService();
                UserPrincipal owner = lookupService.lookupPrincipalByName(metadata.getOwnerName().getValue());
                GroupPrincipal group = lookupService.lookupPrincipalByGroupName(metadata.getGroupName().getValue());
                Files.setOwner(filePath, owner);
                Files.setAttribute(filePath, "posix:group", group);
            } catch (IOException e) {
                System.err.println("AVERTISSEMENT: Impossible de définir le propriétaire/groupe POSIX. Détails: " + e.getMessage());
            }
        }
    }
    private void applyWindowsAcls(Path filePath, FileChunkMessage metadata, AclFileAttributeView aclView) throws IOException {
        UserPrincipalLookupService lookupService = filePath.getFileSystem().getUserPrincipalLookupService();
        List<java.nio.file.attribute.AclEntry> newAclList = new ArrayList<>();
        for (AclEntry protoAcl : metadata.getWindowsAclsList()) {
            try {
                UserPrincipal principal = lookupService.lookupPrincipalByName(protoAcl.getPrincipal());
                java.nio.file.attribute.AclEntry.Builder aclEntryBuilder = java.nio.file.attribute.AclEntry.newBuilder()
                        .setType(AclEntryType.valueOf(protoAcl.getType()))
                        .setPrincipal(principal);
                Set<AclEntryPermission> perms = protoAcl.getPermissionsList().stream()
                        .map(AclEntryPermission::valueOf).collect(Collectors.toSet());
                Set<AclEntryFlag> flags = protoAcl.getFlagsList().stream()
                        .map(AclEntryFlag::valueOf).collect(Collectors.toSet());
                aclEntryBuilder.setPermissions(perms);
                aclEntryBuilder.setFlags(flags);
                newAclList.add(aclEntryBuilder.build());
            } catch (UserPrincipalNotFoundException | IllegalArgumentException e) {
                System.err.println("AVERTISSEMENT: Impossible de résoudre le principal '" + protoAcl.getPrincipal() + "' ou une permission/flag sur le système destination. L'entrée ACL est ignorée.");
            }
        }
        if (!newAclList.isEmpty()) {
            aclView.setAcl(newAclList);
        }
    }

    /**
     * Écrit les chunks dans un fichier temporaire, en appliquant le déchiffrement et la décompression.
     */
    public void writeChunksToTempFile(Path tempPath, List<FileChunkMessage> chunks, CryptoService cryptoService, CompressionService compressionService) throws IOException, GeneralSecurityException {
        if (chunks.isEmpty()) return;

        FileChunkMessage metadata = chunks.get(0);
        byte[] encryptedSymmetricKey = metadata.getEncryptedSymmetricKey().toByteArray();
        String cipherName = metadata.hasEncryptionCipher() ? metadata.getEncryptionCipher().getValue() : null;
        boolean isEncrypted = !metadata.getEncryptedSymmetricKey().isEmpty() && cipherName != null;

        try (OutputStream os = Files.newOutputStream(tempPath)) {
            for (FileChunkMessage chunk : chunks) {
                byte[] data = chunk.getData().toByteArray();

                if (isEncrypted) {
                    data = cryptoService.decrypt(data, encryptedSymmetricKey, cipherName);
                }

                CompressionAlgorithm compressionAlgo = chunk.getCompressionAlgorithm();
                // APPEL CORRIGÉ : N'utilise plus que 2 arguments, ce qui correspond à la nouvelle signature.
                data = compressionService.decompress(data, compressionAlgo.name());
                
                os.write(data);
            }
        }
    }
}