package com.example.kafka.filetransfer.kafka;

import com.example.kafka.filetransfer.model.TransferConfig;
import com.example.kafka.filetransfer.proto.StatusMessage;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * Service responsable de la publication des messages de statut sur le topic de statut Kafka.
 */
public class StatusReporter implements AutoCloseable {

    private static final Logger logger = LoggerFactory.getLogger(StatusReporter.class);
    private final KafkaProducer<String, byte[]> producer;
    private final String statusTopic;
    private final String hostname; // Champ final

    public StatusReporter(TransferConfig config) {
        this.producer = new KafkaProducer<>(config.getKafkaProducerProperties());
        this.statusTopic = config.getStatusTopic();
        
        // --- CORRECTION APPLIQUÉE ICI ---
        String localHostname;
        try {
            localHostname = InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            localHostname = "unknown";
            logger.warn("Impossible de déterminer le nom d'hôte local.", e);
        }
        this.hostname = localHostname; // Assignation unique à la variable final
    }

    /**
     * Envoie un rapport de statut au topic de statut.
     * @param transferId L'ID unique du transfert.
     * @param status Le statut à rapporter.
     * @param message Un message descriptif.
     */
    public void report(String transferId, StatusMessage.Status status, String message) {
        StatusMessage statusMessage = StatusMessage.newBuilder()
                .setTransferId(transferId)
                .setStatus(status)
                .setMessage(message)
                .setTimestampEpoch(System.currentTimeMillis())
                .setHostname(hostname)
                .build();

        ProducerRecord<String, byte[]> record = new ProducerRecord<>(statusTopic, transferId, statusMessage.toByteArray());
        producer.send(record, (metadata, exception) -> {
            if (exception != null) {
                logger.error("Échec de l'envoi du message de statut pour le transfert {}", transferId, exception);
            } else {
                logger.info("Statut '{}' rapporté pour le transfert '{}'.", status.name(), transferId);
            }
        });
    }

    @Override
    public void close() {
        if (producer != null) {
            producer.flush();
            producer.close();
            logger.debug("StatusReporter fermé.");
        }
    }
}