package com.example.kafka.filetransfer.consumer;

import com.example.kafka.filetransfer.kafka.StatusReporter;
import com.example.kafka.filetransfer.model.InProgressTransfer;
import com.example.kafka.filetransfer.model.TransferConfig;
import com.example.kafka.filetransfer.proto.CompressionAlgorithm;
import com.example.kafka.filetransfer.proto.FileChunkMessage;
import com.example.kafka.filetransfer.proto.StatusMessage;
import com.example.kafka.filetransfer.service.*;
import com.google.protobuf.InvalidProtocolBufferException;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.InterruptException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.*;
import java.security.GeneralSecurityException;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Stream;

public class FileTransferConsumer {

    private static final Logger logger = LoggerFactory.getLogger(FileTransferConsumer.class);
    // ... (toutes les autres déclarations de champs restent identiques)
    private final TransferConfig config;
    private final Path destinationDir;
    private final KafkaConsumer<String, byte[]> kafkaConsumer;
    private final Map<String, InProgressTransfer> inProgressTransfers = new ConcurrentHashMap<>();
    private final AtomicBoolean running = new AtomicBoolean(true);
    private final Path stagingBaseDir;
    private final ScheduledExecutorService cleanupScheduler;
    private final StatusReporter statusReporter;
    private final CryptoService cryptoService;
    private final CompressionService compressionService;
    private final HashingService hashingService;
    private final ManifestService manifestService;


    public FileTransferConsumer(TransferConfig config, Path destinationDir) {
        // ... (le constructeur reste identique)
        this.config = config;
        this.destinationDir = destinationDir;
        this.kafkaConsumer = new KafkaConsumer<>(config.getKafkaConsumerProperties());
        this.stagingBaseDir = Paths.get(config.getStagingDirectory());

        try {
            Files.createDirectories(stagingBaseDir);
        } catch (IOException e) {
            throw new RuntimeException("Impossible d'initialiser le répertoire de transit.", e);
        }

        this.cleanupScheduler = Executors.newSingleThreadScheduledExecutor();

        this.statusReporter = new StatusReporter(config);
        this.cryptoService = new CryptoService(config);
        this.compressionService = new CompressionService();
        this.hashingService = new HashingService();
        this.manifestService = new ManifestService(config);
    }

    public void start() {
        // ... (la méthode start reste identique)
        long timeoutMillis = TimeUnit.HOURS.toMillis(config.getTransferTimeoutHours());
        cleanupScheduler.scheduleAtFixedRate(() -> cleanupAbandonedTransfers(timeoutMillis), 1, 1, TimeUnit.HOURS);

        kafkaConsumer.subscribe(Collections.singletonList(config.getDataTopic()));
        logger.info("Consommateur démarré. En écoute sur le topic '{}'", config.getDataTopic());
        logger.info("Nettoyage des transferts abandonnés activé (timeout: {} heures).", config.getTransferTimeoutHours());

        try {
            while (running.get()) {
                ConsumerRecords<String, byte[]> records = kafkaConsumer.poll(Duration.ofMillis(500));
                for (ConsumerRecord<String, byte[]> record : records) {
                    processRecord(record);
                }
                if (!records.isEmpty()) {
                    kafkaConsumer.commitSync();
                }
            }
        } catch (InterruptException e) {
            // Note: le log de cette exception est géré dans ConsumerCommand
            throw e;
        } finally {
            close();
        }
    }

    private void processRecord(ConsumerRecord<String, byte[]> record) {
        FileChunkMessage message = null;
        try {
            message = FileChunkMessage.parseFrom(record.value());
            String transferId = message.getTransferId();

            // MODIFIÉ: Ajout du contexte de transfert (TID) pour tous les logs de cette méthode
            MDC.put("transferId", "[TID:" + transferId.substring(0, 8) + "] ");

            InProgressTransfer transfer = inProgressTransfers.computeIfAbsent(transferId, k -> {
                try {
                    logger.info("Nouveau transfert détecté. Création du répertoire de transit.");
                    return new InProgressTransfer(stagingBaseDir.resolve(k));
                } catch (IOException e) {
                    throw new RuntimeException("Impossible de créer le répertoire de transit pour " + k, e);
                }
            });

            if (!message.getIsFinalChunk()) {
                Path chunkPath = transfer.getStagingDirectory().resolve(message.getChunkNumber() + ".chunk");
                Files.write(chunkPath, message.getData().toByteArray());
                logger.debug("Chunk {}/{} écrit sur le disque.", message.getChunkNumber(), message.getTotalChunks());
            }

            transfer.addChunkMetadata(message);

            if (transfer.isComplete()) {
                logger.info("Transfert complet. Démarrage de la reconstruction pour '{}'.", message.getFileName());
                reconstructFile(transfer);
                inProgressTransfers.remove(transferId);
            }
        } catch (InvalidProtocolBufferException e) {
            logger.error("Impossible de désérialiser le message Protobuf. Offset: {}, Partition: {}. Message ignoré.", record.offset(), record.partition(), e);
        } catch (IOException e) {
            logger.error("Erreur d'IO durant l'écriture d'un chunk sur le disque. Le transfert pourrait échouer.", e);
        } catch (RuntimeException e) {
            logger.error("Erreur non gérée durant le traitement d'un message.", e);
        } finally {
            // MODIFIÉ: Nettoyage du contexte de transfert
            MDC.remove("transferId");
        }
    }

    private void reconstructFile(InProgressTransfer transfer) {
        // ... (la méthode reconstructFile reste identique)
        FileChunkMessage metadata = transfer.getFinalChunkMetadata();
        String transferId = metadata.getTransferId();
        String fileName = metadata.getFileName();
        Path finalPath = destinationDir.resolve(fileName);
        Path tempPath = Paths.get(finalPath + "." + transferId + ".tmp");
        Path stagingDir = transfer.getStagingDirectory();

        try {
            statusReporter.report(transferId, StatusMessage.Status.RECONSTRUCTION_STARTED, "Reconstruction démarrée pour " + fileName);
            List<Path> sortedChunkFiles = transfer.getSortedChunkFiles();
            assembleChunksFromDisk(tempPath, sortedChunkFiles, metadata);
            hashingService.verifyFileIntegrity(tempPath, metadata.getFileHash(), metadata.getHashAlgorithm());
            logger.info("Intégrité vérifiée.");
            manifestService.applyMetadata(tempPath, metadata);
            logger.info("Métadonnées appliquées.");
            Files.move(tempPath, finalPath, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            logger.info("Fichier '{}' reconstruit avec succès à : {}", fileName, finalPath);
            statusReporter.report(transferId, StatusMessage.Status.RECONSTRUCTION_SUCCESS, "Fichier reconstruit avec succès à " + finalPath);
        } catch (IOException | GeneralSecurityException | SecurityException e) {
            logger.error("Échec de la reconstruction : {}", e.getMessage(), e);
            statusReporter.report(transferId, StatusMessage.Status.TRANSFER_FAILED, "Échec de la reconstruction : " + e.getMessage());
        } finally {
            cleanupTransferResources(tempPath, stagingDir);
        }
    }
    
    // ... (toutes les autres méthodes restent identiques : assembleChunksFromDisk, cleanupAbandonedTransfers, etc.)
    private void assembleChunksFromDisk(Path targetFile, List<Path> chunkFiles, FileChunkMessage metadata) throws IOException, GeneralSecurityException {
        byte[] encryptedSymmetricKey = metadata.getEncryptedSymmetricKey().toByteArray();
        String cipherName = metadata.hasEncryptionCipher() ? metadata.getEncryptionCipher().getValue() : null;
        boolean isEncrypted = !metadata.getEncryptedSymmetricKey().isEmpty() && cipherName != null;
        CompressionAlgorithm compressionAlgo = metadata.getCompressionAlgorithm();
        try (OutputStream os = Files.newOutputStream(targetFile)) {
            for (Path chunkFile : chunkFiles) {
                byte[] data = Files.readAllBytes(chunkFile);
                if (isEncrypted) {
                    data = cryptoService.decrypt(data, encryptedSymmetricKey, cipherName);
                }
                data = compressionService.decompress(data, compressionAlgo.name());
                os.write(data);
            }
        }
    }

    private void cleanupAbandonedTransfers(long timeoutMillis) {
        logger.info("Exécution de la tâche de nettoyage des transferts abandonnés...");
        long currentTime = System.currentTimeMillis();
        int cleanupCount = 0;
        MDC.put("appName", "consumer-cleanup"); // Contexte pour la tâche de fond

        Iterator<Map.Entry<String, InProgressTransfer>> iterator = inProgressTransfers.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, InProgressTransfer> entry = iterator.next();
            InProgressTransfer transfer = entry.getValue();

            if (currentTime - transfer.getLastUpdateTime() > timeoutMillis) {
                String transferId = entry.getKey();
                MDC.put("transferId", "[TID:" + transferId.substring(0, 8) + "] ");
                logger.warn("Transfert abandonné détecté (dépassement du timeout de {} ms). Nettoyage des ressources.", timeoutMillis);
                cleanupTransferResources(null, transfer.getStagingDirectory());
                iterator.remove();
                cleanupCount++;
                MDC.remove("transferId");
            }
        }
        if (cleanupCount > 0) {
            logger.info("Nettoyage terminé. {} transfert(s) abandonné(s) supprimé(s).", cleanupCount);
        }
        MDC.remove("appName");
    }

    private void cleanupTransferResources(Path tempFile, Path stagingDir) {
        try {
            if (tempFile != null && Files.exists(tempFile)) {
                Files.delete(tempFile);
                logger.debug("Fichier temporaire '{}' nettoyé.", tempFile);
            }
            if (stagingDir != null && Files.exists(stagingDir)) {
                 try (Stream<Path> walk = Files.walk(stagingDir)) {
                    walk.sorted(Comparator.reverseOrder()).forEach(path -> {
                        try {
                            Files.delete(path);
                        } catch (IOException e) {
                            logger.error("Impossible de supprimer {}", path, e);
                        }
                    });
                }
                logger.info("Répertoire de transit '{}' nettoyé.", stagingDir);
            }
        } catch (IOException ex) {
            logger.error("Erreur lors du nettoyage des ressources pour '{}'.", stagingDir.getFileName(), ex);
        }
    }

    public void shutdown() {
        running.set(false);
    }

    private void close() {
        if (cleanupScheduler != null) {
            cleanupScheduler.shutdownNow();
        }
        if (kafkaConsumer != null) {
            kafkaConsumer.close();
        }
        if (statusReporter != null) {
            statusReporter.close();
        }
        logger.info("Ressources du consommateur fermées.");
    }
}