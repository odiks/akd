package com.example.kafka.filetransfer.kafka;

import com.example.kafka.filetransfer.model.TransferConfig;
import com.example.kafka.filetransfer.proto.FileChunkMessage;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.Future;

/**
 * Service responsable de la publication des messages de chunk de fichier sur le topic de données Kafka.
 */
public class KafkaChunkPublisher implements AutoCloseable {

    private static final Logger logger = LoggerFactory.getLogger(KafkaChunkPublisher.class);
    private final KafkaProducer<String, byte[]> producer;
    private final String dataTopic;

    public KafkaChunkPublisher(TransferConfig config) {
        this.producer = new KafkaProducer<>(config.getKafkaProducerProperties());
        this.dataTopic = config.getDataTopic();
    }

    /**
     * Publie un message de chunk de manière asynchrone.
     * @param message Le message Protobuf à envoyer.
     */
    public void publish(FileChunkMessage message) {
        ProducerRecord<String, byte[]> record = new ProducerRecord<>(dataTopic, message.getTransferId(), message.toByteArray());
        producer.send(record, (metadata, exception) -> {
            if (exception != null) {
                logger.error("Échec de l'envoi du chunk {}/{} pour le transfert {}",
                        message.getChunkNumber(), message.getTotalChunks(), message.getTransferId(), exception);
            }
        });
    }

    /**
     * Publie un message de chunk de manière synchrone (bloquant).
     * Utilisé pour le message final afin de garantir son envoi avant la fin du programme.
     * @param message Le message Protobuf à envoyer.
     * @return Les métadonnées du message envoyé.
     */
    public Future<RecordMetadata> publishSync(FileChunkMessage message) {
        ProducerRecord<String, byte[]> record = new ProducerRecord<>(dataTopic, message.getTransferId(), message.toByteArray());
        return producer.send(record);
    }

    @Override
    public void close() {
        if (producer != null) {
            producer.flush();
            producer.close();
            logger.debug("KafkaChunkPublisher fermé.");
        }
    }
}